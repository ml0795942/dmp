# -*- coding: utf-8 -*-
# Author: Wen Zhang<zhangwen@qiyi.com>

from __future__ import unicode_literals

import datetime

from django.db import models


class DmpSearchWordsApi(models.Model):
    uaa_id = models.CharField(max_length=255)
    end_date = models.TextField()
    class Meta:
        db_table = 'dmp_search_words'
