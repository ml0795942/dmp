# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang<zhangzhenghao@qiyi.com>

import sys
from datetime import datetime
import collections as coll

from django.shortcuts import render
from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponse, JsonResponse
from rest_framework import viewsets
from rest_framework.parsers import JSONParser
from rest_framework.renderers import JSONRenderer
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import exceptions

from common import exception_info
from common.exception_handler import exception_handler
from common.json_response import ListResponse, ReturnId
from common.utils import api_log, calPageStartEnd, checkFieldExist, checkStatusField, column_order, search_result, res_handler
from common.utils import check_auth, checkAudienceIdExist, create_audience_info, audience_id_convert_name, object_value_migrate
import json
from models import DmpSearchWordsApi


class DmpOpenUaaView(viewsets.ViewSet):
    def list(self, request, format=None):
        ret_value = coll.OrderedDict()
        try:
            results = DmpSearchWordsApi.objects.all()
            id_date = {}
            for result in results:
                if result.uaa_id in id_date:
                    id_date[result.uaa_id] = max(id_date[result.uaa_id], result.end_date)
                else:
                    id_date[result.uaa_id] = result.end_date
            data = [{"id":str(uaa_id), "end_date":id_date[uaa_id]} for uaa_id in id_date]
            ret = """{"code":%s,"data":[%s],"msg":%s}""" % ("success",json.dumps(data),"请求成功")
            ret_value["code"] = "success"
            ret_value["data"] = data
            ret_value["msg"] = "请求成功".encode("utf-8")
            resp = JsonResponse(ret_value, json_dumps_params={"ensure_ascii":False})
        except Exception as e:
            ret_value["code"] = "fail"
            ret_value["data"] = {}
            ret_value["msg"] = str(e)
            resp = JsonResponse(ret_value)
        return resp
