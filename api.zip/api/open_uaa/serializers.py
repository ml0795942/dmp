# -*- coding:utf-8 -*-
# Author: Wen Zhang<zhangwen@qiyi.com>

from rest_framework import serializers

from common import exception_info
from models import DmpOpenUaaReturn
