"""api URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/dev/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from rest_framework import routers

from relativity import views as relativity_views
from audience import views as audience_views
from dsp import views as dsp_views
from lookalike import views as lookalike_views
from click import views as click_views
from search import views as search_views
from fans import views as fans_views
from star import views as star_views
from open_uaa import views as openuaa_views

router = routers.DefaultRouter()
router.register(r'test', relativity_views.TestView, base_name='test')
router.register(r'user', relativity_views.UserView, base_name='user')
router.register(r'relativity', relativity_views.CpcRelativityView, base_name='relativity')
router.register(r'audience', audience_views.DmpAudienceInfoView, base_name='audience')
router.register(r'audience/task', audience_views.DmpTaskAudienceUpdateView, base_name='audience_task')
router.register(r'audience/schedule', audience_views.DmpAudienceScheduleView, base_name='audience_schedule')
router.register(r'click', click_views.DmpClickRetargetingView, base_name='click')
router.register(r'dsp', dsp_views.DmpDspInfoView, base_name='dsp')
router.register(r'dsp/schedule', dsp_views.DmpDspScheduleView, base_name='dsp_schedule')
router.register(r'lookalike', lookalike_views.DmpLookalikeView, base_name='lookalike')
router.register(r'search', search_views.DmpSearchWordsView, base_name='search')
router.register(r'fans', fans_views.DmpVideoFansView, base_name='fans')
router.register(r'star', star_views.DmpQipuPersonView, base_name='star')
router.register(r'open_uaa', search_views.DmpOpenUaaView, base_name='api_openuaa')


urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^', include(router.urls)),
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework')),
]
