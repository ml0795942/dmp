# -*- coding: utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

from __future__ import unicode_literals

import datetime

from django.db import models


class DmpClickRetargeting(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    audience_target_id = models.BigIntegerField()
    status = models.SmallIntegerField(default='0')
    end_date = models.DateField(default=datetime.date.today()+datetime.timedelta(days=30))
    update_time = models.DateTimeField(auto_now=True)
    order_items = models.TextField()
    type = models.SmallIntegerField()
    couchbase_flag = models.SmallIntegerField()
    cid_or_uid = models.SmallIntegerField()
    tracking_type = models.SmallIntegerField()

    class Meta:
        db_table = 'dmp_retargeting'


class DmpClickRetargetingConvert(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    audience_target_id = models.CharField(max_length=255)
    status = models.SmallIntegerField(default='0')
    end_date = models.DateField(default=datetime.date.today()+datetime.timedelta(days=30))
    update_time = models.DateTimeField(auto_now=True)
    order_items = models.TextField()
    type = models.SmallIntegerField()
    couchbase_flag = models.SmallIntegerField()
    cid_or_uid = models.SmallIntegerField()
