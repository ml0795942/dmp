# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang <zhangzhenghao@qiyi.com>

from django.test import TestCase
from rest_framework.test import APITestCase
from rest_framework.test import APIRequestFactory

from models import DmpClickRetargeting
from common import exception_info

URL = '/click/'

DATA = {'name': 'test', 'order_items': '5000000827803', 'couchbase_flag': '0', 'caa_or_uaa': '1', 'type': '1'}

class ClickTest(APITestCase):
 
    def test_create_click(self):
        tmp_data = {'name': 'test'}     
        response = self.client.post(URL, tmp_data, format='json')
        self.assertContains(response.data, '"couchbase_flag":["请填写合法的整数值。"],"type":["请填写合法的整数值。"],"order_items":["该字段不能为空。"],"caa_or_uaa":["请填写合法的整数值。"]', status_code=400) 
        respoonse = self.client.post(URL, DATA, fomat='json')
        self.assertEquals(DmpClickRetargeting.objects.count(), 1)
        self.assertEquals(DmpClickRetargeting.objects.get(id=1).type, 1)
        response = self.client.get(URL)
        print response
        self.assertEquals(response.data.count, 1)
