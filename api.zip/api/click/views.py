# -*- coding:utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#         Zhenghao Zhang<zhangzhenghao@qiyi.com>

import sys
from datetime import datetime

from django.shortcuts import render
from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import viewsets
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import exceptions

from common import exception_info
from common.exception_handler import exception_handler
from common.json_response import ListResponse, ReturnId
from common.utils import calPageStartEnd, checkFieldExist, checkStatusField, column_order, search_result, res_handler
from common.utils import api_log, check_auth, create_audience_info, audience_id_convert_name, object_value_migrate, add_user, check_perm
from models import DmpClickRetargeting
from models import DmpClickRetargetingConvert
from serializers import DmpClickRetargetingSerializer, DmpClickRetargetingCheckSerializer, DmpClickRetargetingListSerializer
from audience.serializers import DmpAudienceIdResponseSerializer


class DmpClickRetargetingView(viewsets.ViewSet):

    def create(self, request, format=None):
        check_auth(request)
        check_perm(request, 'click.add_dmpclickretargeting')
        serializer = DmpClickRetargetingCheckSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        name = request.data['name']
        cid_or_uid = request.data['cid_or_uid']
        audience_type = request.data['audience_type']
        id = create_audience_info(name, cid_or_uid, audience_type)
        cli = DmpClickRetargeting()
        cli.name = name
        cli.audience_target_id = id
        cli.order_items = request.data['order_items']
        cli.couchbase_flag = request.data['couchbase_flag']
        cli.cid_or_uid = cid_or_uid
        cli.type = int(request.data['type'])
        cli.tracking_type = int(request.data['tracking_type'])
        if checkFieldExist(request, 'end_date'):
            cli.end_date = request['end_date']
        cli.save()
        response_id = ReturnId(id)
        serializer_context = {
            'request': Request(request),
        }
        res = DmpAudienceIdResponseSerializer(instance=response_id, context=serializer_context)
	api_log('POST DmpClickRetargetingView', request, cli, 'DEBUG')
        return Response(res.data)

    def list(self, request, format=None):
        add_user(request)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        results = DmpClickRetargeting.objects.all().order_by('-id')
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            value_convert_json = {'type' : {0 : '奇胜',1 : '奇效',},'cid_or_uid' : {0 : 'cupid_user_id',1 : 'uaa_user_id',},\
                'status' : {0 : '创建待例行化', 1 : '例行化中',2 : '停止更新',},'couchbase_flag' : {0 : '不写入', 1 : 'copy', 2 : 'move',}}
            keys = ['type', 'cid_or_uid', 'status', 'couchbase_flag']
            temp_results = results
            res_handler(temp_results, keys, value_convert_json)
            list = search_result(results,temp_results, search)
            results = DmpClickRetargeting.objects.filter(id__in=list)
        results = column_order(results, sort, order)
        count = len(results)
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        #convert_results = []
        #results = page_results
        #for result in results:
        #    task = DmpClickRetargetingConvert()
        #    object_value_migrate(task, result)
        #    convert_results.append(task)
        #for result in convert_results:
        #    result.audience_target_id = audience_id_convert_name(result.audience_target_id).strip(';')
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = DmpClickRetargetingListSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)

    def put(self, request, pk=None, format=None):
        check_auth(request)
        check_perm(request, 'click.change_dmpclickretargeting')
        if not checkFieldExist(request, 'id'): raise exceptions.APIException(exception_info.ID_REQUIRED)
        try:
            cli = DmpClickRetargeting.objects.get(id=request.data['id'])
        except DmpClickRetargeting.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        if checkFieldExist(request, 'name'):
            cli.name = request.data['name']
        if checkFieldExist(request, 'order_items'):
            cli.order_items = request.data['order_items']
        if checkFieldExist(request, 'end_date'):
            cli.end_date = request.data['end_date']
        if checkFieldExist(request, 'couchbase_flag'):
            cli.couchbase_flag = request.data['couchbase_flag']
        if checkFieldExist(request, 'status'):
            cli.status = request.data['status']
        cli.save()
        serializer_context = {
            'request': Request(request),
        }
        res = DmpClickRetargetingSerializer(instance=cli, context=serializer_context)
        api_log('PUT DmpClickRetargetingView', request, cli, 'DEBUG')
        return Response(res.data)
