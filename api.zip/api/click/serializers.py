# -*- coding:utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

from rest_framework import serializers

from common import exception_info
from models import DmpClickRetargeting

class DmpClickRetargetingSerializer(serializers.ModelSerializer):
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    end_date = serializers.DateTimeField(format=None, input_formats=None)
    audience_target_id = serializers.CharField(required=False)

    class Meta:
        model = DmpClickRetargeting

    def validate_type(self, value):
        type = int(value)
        if not (type == 1 or type == 0):
            raise serializers.ValidationError(exception_info.TYPE_OF_CLICK_RETARGETING)

    def validate_status(self, value):
        status = int(value)
        if not (status == 1 or status == 0 or status == 2):
            raise serializers.ValidationError(exception_info.STATUS_OUT_OF_RANGE_3)

    def validate_couchbase_flag(self, value):
        couchbase_flag = int(value)
        if not (couchbase_flag == 0 or couchbase_flag == 1 or couchbase_flag == 2):
            raise serializers.ValidationError(exception_info.COUCHBASE_FLAG_EXCEPTION)

    def validate_cid_or_uid(self, value):
        cid_or_uid = int(value)
        if not (cid_or_uid == 0 or cid_or_uid == 1):
            raise serializers.ValidationError(exception_info.CAA_OR_UAA_RANGE_EXCEPTION)

    def validate_tracking_type(self, value):
        tracking_type = int(value)
        if not (tracking_type == 0 or tracking_type == 1):
            raise serializers.ValidationError(exception_info.TRACKING_TYPE_EXCEPTION)


class DmpClickRetargetingCheckSerializer(serializers.Serializer):
    name = serializers.CharField()
    cid_or_uid = serializers.IntegerField()
    order_items = serializers.CharField()
    couchbase_flag = serializers.IntegerField()
    type = serializers.IntegerField()
    audience_type = serializers.IntegerField()


class DmpClickRetargetingConvertSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()
    status = serializers.IntegerField()
    end_date = serializers.DateTimeField(format=None, input_formats=None)
    order_items = serializers.CharField()
    type = serializers.IntegerField()
    couchbase_flag = serializers.IntegerField()
    cid_or_uid = serializers.IntegerField()
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    audience_target_id = serializers.CharField()

    def validate_type(self, value):
        type = int(value)
        if not (type == 1 or type == 0):
            raise serializers.ValidationError(exception_info.TYPE_OF_CLICK_RETARGETING)

    def validate_status(self, value):
        status = int(value)
        if not (status == 1 or status == 0 or status == 2):
            raise serializers.ValidationError(exception_info.STATUS_OUT_OF_RANGE_3)

    def validate_couchbase_flag(self, value):
        couchbase_flag = int(value)
        if not (couchbase_flag == 0 or couchbase_flag == 1 or couchbase_flag == 2):
            raise serializers.ValidationError(exception_info.COUCHBASE_FLAG_EXCEPTION)

    def validate_cid_or_uid(self, value):
        cid_or_uid = int(value)
        if not (cid_or_uid == 0 or cid_or_uid == 1):
            raise serializers.ValidationError(exception_info.CAA_OR_UAA_RANGE_EXCEPTION)

    def validate_tracking_type(self, value):
        tracking_type = int(value)
        if not (tracking_type == 0 or tracking_type == 1):
            raise serializers.ValidationError(exception_info.TRACKING_TYPE_EXCEPTION)


class DmpClickRetargetingListSerializer(serializers.Serializer):
    results = DmpClickRetargetingSerializer(many=True)
    count = serializers.IntegerField()
    page_size = serializers.IntegerField()
