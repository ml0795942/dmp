from __future__ import unicode_literals

from django.apps import AppConfig


class ClickConfig(AppConfig):
    name = 'click'
