# -*- coding:utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#         Zhenghao Zhang<zhangzhenghao@qiyi.com>

import sys
from datetime import datetime

from django.shortcuts import render
from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import viewsets
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import exceptions

from common import exception_info
from common.exception_handler import exception_handler
from common.json_response import ListResponse, ReturnId
from common.utils import calPageStartEnd, checkFieldExist, checkStatusField, column_order, search_result, res_handler
from common.utils import api_log, check_auth
from models import DmpClickRetargeting
from serializers import DmpClickRetargetingSerializer, DmpClickRetargetingListSerializer


class DmpClickRetargetingView(viewsets.ViewSet):

    def create(self, request, format=None):
        check_auth(request)
        serializer = DmpClickRetargetingSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        cli = DmpClickRetargeting()
        cli.name = request.data['name']
        cli.order_items = request.data['order_items']
        cli.couchbase_flag = request.data['couchbase_flag']
        cli.caa_or_uaa = request.data['caa_or_uaa']
        cli.type = int(request.data['type'])
        if checkFieldExist(request, 'end_date'):
            cli.end_date = request['end_date']
        cli.save()
        res_cli = DmpClickRetargeting.objects.get(id=cli.id)
        serializer_context = {
            'request': Request(request),
        }
        res = DmpClickRetargetingSerializer(instance=res_cli, context=serializer_context)
	api_log('CREATE CLICK_RETARGETING', request, cli)
        return Response(res.data)

    def list(self, request, format=None):
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        results = DmpClickRetargeting.objects.all().order_by('-id')
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            value_convert_json = {'type' : {0 : '奇胜',1 : '奇效',},'caa_or_uaa' : {0 : 'cupid_user_id',1 : 'uaa_user_id',},\
                'status' : {0 : '创建待例行化', 1 : '例行化中',2 : '停止更新',},'couchbase_flag' : {0 : '不写入', 1 : 'copy', 2 : 'move',}}
            keys = ['type', 'caa_or_uaa', 'status', 'couchbase_flag']
            temp_results = results
            res_handler(temp_results, keys, value_convert_json)
            list = search_result(results,temp_results, search)
            results = DmpClickRetargeting.objects.filter(id__in=list)
        results = column_order(results, sort, order)
        count = len(results)
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = DmpClickRetargetingListSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)
        
        
