# -*- coding:utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

from __future__ import unicode_literals

from django.db import models


class DmpLookalike(models.Model):
    id = models.AutoField(primary_key=True)
    parent_id = models.BigIntegerField()
    expect_size = models.IntegerField()
    # default for ignore validation error
    hdfs_url = models.CharField(max_length=255, default='')
    status = models.SmallIntegerField(default='0')
    create_time = models.DateTimeField(auto_now_add=True)
    update_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dmp_lookalike'
    
