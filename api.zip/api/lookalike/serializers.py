# -*- coding:utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

from rest_framework import serializers

from models import DmpLookalike


class DmpLookalikeSerializer(serializers.ModelSerializer):

    class Meta:
        model = DmpLookalike


class DmpLookalikeListResponseSerializer(serializers.Serializer):
    results = DmpLookalikeSerializer(many=True)
    count = serializers.IntegerField()
    page_size = serializers.IntegerField() 


class DmpLookalikeIdResponseSerializer(serializers.Serializer):
    id = serializers.IntegerField()


class DmpAudienceIdStatusResponseSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    status = serializers.IntegerField()
