# -*- coding:utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

import time
import sys

from django.shortcuts import render
from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import viewsets
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import exceptions

from common import exception_info
from common.json_response import ListResponse, ReturnId, ReturnIdStatus
from common.utils import calPageStartEnd, checkFieldExist, checkStatusField
from common.utils import api_log, check_auth
from models import DmpLookalike
from serializers import DmpLookalikeSerializer
from serializers import DmpLookalikeListResponseSerializer
from serializers import DmpLookalikeIdResponseSerializer
from serializers import DmpAudienceIdStatusResponseSerializer


class DmpLookalikeView(viewsets.ViewSet):
    
    def create(self, request, format=None):
	check_auth(request)
        serializer = DmpLookalikeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        alike = DmpLookalike()
        # todo parent_id validation
        alike.parent_id = request.data['parent_id']
        alike.expect_size = request.data['expect_size']
        # not save if have history task in one day.
        try: 
            date = time.strftime('%Y-%m-%d',time.localtime(time.time()))
            same_alike = DmpLookalike.objects.filter(parent_id=alike.parent_id,
                                                expect_size=alike.expect_size,
                                                create_time__startswith=date)[:1].get()
            alike.id = same_alike.id
        except DmpLookalike.DoesNotExist:
            alike.save()
        response_id = ReturnId(alike.id)
        serializer_context = { 
            'request': Request(request),
        }   
        res = DmpLookalikeIdResponseSerializer(instance=response_id, context=serializer_context)
	api_log('CREATE LOOKALIKE', request, alike)
        return Response(res.data) 

    def list(self, request, format=None):
        id = request.query_params.get('id')
        status = request.query_params.get('status')
        if id:
            try:
                alike = DmpLookalike.objects.get(id=id)
            except DmpLookalike.DoesNotExist:
                raise exceptions.APIException(exception_info.ID_NOT_EXIST)
            res = ReturnIdStatus(alike.id, alike.status)
            serializer_context = {
                'request': Request(request),
            }
            res = DmpAudienceIdStatusResponseSerializer(instance=res, context=serializer_context)
            return Response(res.data)
        elif status:
            page_size = int(request.query_params.get('page_size', '-1'))
            page = int(request.query_params.get('page', '1'))
            results = DmpLookalike.objects.filter(status=status)
            count = len(results)
	    (start, end) = calPageStartEnd(page, page_size, count)
            page_results = results[start:end]
            list_response = ListResponse(count, page_size, page_results)
            serializer_context = {'request': Request(request)}
            res = DmpLookalikeListResponseSerializer(instance=list_response, context=serializer_context)
            return Response(res.data) 
        else:
            raise exceptions.APIException('Only support by id or status')

    def put(self, request, pk=None, format=None):
	check_auth(request)
        if not checkFieldExist(request, 'id'):
            raise exceptions.APIException(exception_info.ID_REQUIRED)
        try:
            alike = DmpLookalike.objects.get(id=request.data['id'])
        except DmpLookalike.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        if checkFieldExist(request, 'hdfs_url'):
            alike.hdfs_url = request.data['hdfs_url']
        if checkFieldExist(request, 'status'):
            if not checkStatusField(request, 4):
                raise exceptions.APIException(exception_info.STATUS_OUT_OF_RANGE_4)
            alike.status = request.data['status']  
        alike.save()
        serializer_context = {
            'request': Request(request),
        }
        res = DmpLookalikeSerializer(instance=alike, context=serializer_context)
	api_log('UPDATE LOOKALIKE', request, alike)
        return Response(res.data)


