# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang <zhangzhenghao@qiyi.com>

from django.test import TestCase
from rest_framework.test import APITestCase
from rest_framework.test import APIRequestFactory

from models import DmpLookalike
from common import exception_info

URL = '/lookalike/' 
HDFS = '/hive/warehouse/cupid3.db/dmp/tag/activity/output/dt=2016-03-25'


class LookalikeTest(APITestCase):

    def test_create_lookalike(self):
        data = {'parent_id': 2, 'expect_size': 200}
        response = self.client.post(URL, data, format='json')
        self.assertEquals(DmpLookalike.objects.count(), 1)
        self.assertEquals(DmpLookalike.objects.get(parent_id=2).expect_size, 200)
        response = self.client.post(URL, data, format='json')
        self.assertEquals(DmpLookalike.objects.count(), 1)

    def test_id(self):
        data = {'id': '-1'}
        response = self.client.get(URL, data, format='json')
        self.assertEquals(DmpLookalike.objects.count(), 0)
        self.assertEquals(response.data, {"status_code":500,"detail":"id不存在"})

    def test_status(self):
        data = {'status': '-1'}
        response = self.client.get(URL, data, format='json')
        self.assertEquals(DmpLookalike.objects.count(), 0)

    def test_other_type(self):
        response = self.client.get(URL)
        self.assertEquals(response.data,{"status_code":500,"detail":"Only support by id or status"})

    def test_update_lookalike_id_null(self):
        data = {'hdfs_url': HDFS, 'status': '1'}
        response = self.client.put(URL, data, format='json')
        self.assertContains(response, exception_info.ID_REQUIRED, status_code=500)

    def test_update_lookalike_not_exist(self):
        data = {'id': 3, 'hdfs_url': HDFS, 'status': 1}
        response = self.client.put(URL, data, format='json')
        self.assertContains(response, exception_info.ID_NOT_EXIST, status_code=500)

    def test_update_lookalike(self):
        data = {'parent_id': 2, 'expect_size': 300}
        response = self.client.post(URL, data, format='json')
        self.assertEquals(DmpLookalike.objects.get(id=1).status, 0)
        data = {'id': 1, 'hdfs_url': HDFS, 'status': '1'}
        response = self.client.put(URL, data, format='json')
        self.assertEquals(DmpLookalike.objects.get(id=1).status, 1)
        self.assertEquals(DmpLookalike.objects.get(id=1).hdfs_url, HDFS)      
