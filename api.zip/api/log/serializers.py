# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang<zhangzhenghao@qiyi.com>


from rest_framework import serializers

from common import exception_info
from models import DmpLog


class DmpLogSerializer(serializers.ModelSerializer):
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)

    class Meta:
        model = DmpLog
