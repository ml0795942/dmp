# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang<zhangzhenghao@qiyi.com>

from __future__ import unicode_literals

import datetime

from django.db import models


class DmpLog(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.CharField(max_length=255)
    operation = models.CharField(max_length=255)
    app = models.CharField(max_length=255)
    request = models.CharField(max_length=255)
    response = models.TextField()
    update_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dmp_log'
