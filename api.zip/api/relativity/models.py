# -*- coding: utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>

from __future__ import unicode_literals

from django.db import models


class CpcRelativityUpdate(models.Model):
    id = models.AutoField(primary_key=True)
    file_url = models.CharField(max_length=255)
    status = models.SmallIntegerField()
    message = models.CharField(max_length=255)
    update_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'relativity_update'


class CpcRelativity(object):
    
    def __init__(self, key_id, key_type, key_name, match_id, match_id_name, biz_type, match_type, match_score):
        self.key_id = key_id
        self.key_type = key_type
        self.key_name = key_name
        self.match_id = match_id
        self.match_id_name = match_id_name
        self.biz_type = biz_type
        self.match_type = match_type
        self.match_score = match_score
