# -*- coding: utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>

from rest_framework import serializers

from models import CpcRelativity


class CpcRelativityResultSerializer(serializers.Serializer):
    key_id = serializers.CharField(max_length=255)
    key_type = serializers.IntegerField()
    key_name = serializers.CharField(max_length=255)
    match_id = serializers.IntegerField()
    match_id_name = serializers.CharField(max_length=255)
    biz_type = serializers.CharField(max_length=30)
    match_type = serializers.CharField(max_length=10)
    match_score = serializers.FloatField()


class CpcRelativityListResponseSerializer(serializers.Serializer):
    results = CpcRelativityResultSerializer(many=True)
    count = serializers.IntegerField()
    page_size = serializers.IntegerField()
