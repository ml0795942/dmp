# -*- coding:utf-8 -*-
# Author: Guanxiong Liu (liuguanxiong@qiyi.com)

import collections as coll
import gc
import os
import sys
import time

from models import CpcRelativity, CpcRelativityUpdate

reload(sys)  
sys.setdefaultencoding('utf8')

LINE_SEPERATOR = '\1'
FILE_DIR = '/data/algo/relativity/data/match_result'


class FileLoader(object):
    """
    This class is used for loading data file and generating two dictionaries,
    """
    
    key_id_dict = coll.defaultdict(list)
    match_id_dict = coll.defaultdict(list)
    __last_success_url = ''
    __is_loading = False

    @staticmethod
    def reset():
        FileLoader.__last_success_url = ''
        FileLoader.__is_loading = False

    @staticmethod
    def load():
        url = FileLoader.__get_lastest_file()
        FileLoader.loadWithUrl(url)
    
    @staticmethod
    def loadWithUrl(url):
        if FileLoader.__is_loading:
            return
        FileLoader.__is_loading = True
        url = FileLoader.__get_lastest_file()
        if not os.path.exists(url):
            return
        if url == FileLoader.__last_success_url:
            return
        fail_status = 0
        line_num = 0
        fail_num = 0
        start_time = 0
        gc_end_time = 0
        load_end_time = 0
        err_msg = ''
        try:
            start_time = time.time()
            FileLoader.key_id_dict.clear()
            FileLoader.match_id_dict.clear()
            gc.collect()
            gc_end_time = time.time()
            file = open(url)
            while 1:
                line = file.readline()
                if not line:
                    break
                line_num += 1
                field_list = line.strip().split(LINE_SEPERATOR)
                if len(field_list) != 8:
                    fail_num += 1
                    continue
                key_id = field_list[0]
                match_id = int(field_list[3])
                FileLoader.key_id_dict[u'%s' % key_id].append(line)
                FileLoader.match_id_dict[match_id].append(line)
            load_end_time = time.time()
            FileLoader.__last_success_url = url
        except Exception as ex:
            fail_status = 1
            err_msg = sys.exc_info()
        FileLoader.__is_loading = False
        FileLoader.__record_load_result(
            url, line_num, fail_num, start_time, gc_end_time, load_end_time, fail_status, err_msg)

    @staticmethod
    def query(id, type):
        if type == 0:
            return FileLoader.__convert_to_list(FileLoader.key_id_dict[id])
        else:
            return FileLoader.__convert_to_list(FileLoader.match_id_dict[int(id)])

    @staticmethod
    def __convert_to_list(lines):
        if len(lines) == 0:
            return []
        else:
            return [FileLoader.__convert_to_relativity_obj(line) for line in lines]
    
    @staticmethod
    def __convert_to_relativity_obj(line):
        line = line.strip()
        field_list = line.split(LINE_SEPERATOR)
        key_id = field_list[0]
        key_type = int(field_list[1])
        key_name = field_list[2]
        match_id = int(field_list[3])
        match_id_name = field_list[4]
        biz_type = field_list[5]
        match_type = field_list[6]
        match_score = float(field_list[7])
        # build relativity result
        cpc_relativity = CpcRelativity(key_id,
                                       key_type,
                                       key_name,
                                       match_id,
                                       match_id_name,
                                       biz_type,
                                       match_type,
                                       match_score)
        return cpc_relativity

    @staticmethod
    def __get_lastest_file():
        file_dir_list = os.listdir(FILE_DIR)
        max_dir = max(file_dir_list)
        done_file = '%s/%s/_done' % (FILE_DIR, max_dir)
        if not os.path.exists(done_file):
            file_dir_list.remove(max_dir)
            max_dir = max(file_dir_list)
	return '%s/%s/match_result' % (FILE_DIR, max_dir)
   
    @staticmethod 
    def __record_load_result(file_url, total_cnt, fail_cnt, start_time, gc_end_time, load_end_time, status, err_msg):
        if status == 0:
            message = 'total_cnt = %d, fail_cnt = %d, gc_cost(s) = %d, load_cost(s) = %d' % (
                       total_cnt, fail_cnt, (gc_end_time - start_time), (load_end_time - gc_end_time))
        else:
            message = err_msg
        load_result = CpcRelativityUpdate()
        load_result.file_url = file_url
        load_result.status = status
        load_result.message = message
        load_result.save()
