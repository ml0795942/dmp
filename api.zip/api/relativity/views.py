# -*- coding: utf-8 -*-
# Author: Guanxiong Liu <liuguanxiong@qiyi.com>

import logging
import json

import jieba
from django.core import serializers
from django.shortcuts import render
from rest_framework import viewsets
from rest_framework import exceptions
from rest_framework.request import Request
from rest_framework.response import Response

from common.json_response import ListResponse
from common.utils import calPageStartEnd, checkFieldExist
from file_loader import FileLoader
from serializers import CpcRelativityListResponseSerializer

#logger = logging.getLogger('test')

class TestView(viewsets.ViewSet):
    
    def list(self, request, format=None):
        #logger.debug('remote user = ' + request.META['REMOTE_USER'])
        return Response({'detail': "Hello REST World"})


class UserView(viewsets.ViewSet):

    def list(self, request, format=None):
        if 'REMOTE_USER' in request.META:
            return Response(request.META['REMOTE_USER'])
        else:
            return Response('Anonymous')


class CpcRelativityView(viewsets.ViewSet):

    def list(self, request, format=None):
        type = request.query_params.get('type', 'KEY_ID')
        query = request.query_params.get('query', None)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        results = []
        if query:
            query = query.upper()
            if type == 'KEY_ID':
                seg_list = filter(lambda x: len(x) > 1, [keywrod.strip() for keywrod in jieba.cut(query.encode("utf-8"), cut_all=True)])
                if not seg_list:
                    seg_list = [query]
                for seg in seg_list:
                    results.extend(FileLoader.query(seg, 0))
            elif type == 'MATCH_ID':
                results.extend(FileLoader.query(query, 1))
            else:
                raise exceptions.APIException('Unknow type. Only support KEY_ID/MATCH_ID')
        count = len(results)
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = CpcRelativityListResponseSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)

    def put(self, request, pk=None, format=None):
        if not checkFieldExist(request, 'token'):
            raise exceptions.APIException('Token required.')
        if request.data['token'] != 'aec73d50-06b8-11e6-ab73-ecf4bbec3b68':
            raise exceptions.APIException('Token invalid.')
        if checkFieldExist(request, 'reset'):
            FileLoader.reset()
        if checkFieldExist(request, 'path'):
            FileLoader.loadWithUrl(request.data['path'])
        else:
            FileLoader.load()
        return Response(True)
