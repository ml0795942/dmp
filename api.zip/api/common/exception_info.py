# -*- coding:utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

PERMISSION_ERROR = "权限不够,请联系管理员."

ID_REQUIRED = "id不能为空"
ID_NOT_EXIST = "id不存在"

AUDIENCE_ID_NOT_EXIST = "audience_id不存在"
AUDIENCE_ID_TYPE_RANGE = "只能取0或1"
AUDIENCE_TYPE_RANGE = "只能取1~8之间的整数值"

DSP_ID_EXIST = "dsp_id已存在"
DSP_ID_NOT_EXIST = "dsp_id不存在"

AUDIENCE_ID_NOT_EXIST = "audience_id不存在"

STATUS_OUT_OF_RANGE_1 = "Status只能为0,1,2,-1"
STATUS_OUT_OF_RANGE_2 = "Status只能为0或1"
STATUS_OUT_OF_RANGE_3 = "Status只能为0,1,2"
STATUS_OUT_OF_RANGE_4 = "Status只能为0,1,2,3"

TYPE_OF_CLICK_RETARGETING = "Type只能为0或1"

COUCHBASE_FLAG_EXCEPTION = "Couchbase_flag只能为0,1,2"

CAA_OR_UAA_RANGE_EXCEPTION = "caa_or_uaa只能为0或1"

TRACKING_TYPE_EXCEPTION = "tracking_type只能为0或1"

TOO_MUCH_EPISODES = "Episodes number more than 5000"
