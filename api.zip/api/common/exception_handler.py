# -*- coding:utf-8 -*-
# Author: Guanxiong Liu <liuguanxiong@qiyi.com>
#         Zhenghao Zhang <zhangzhenghao@qiyi.com>

import json

from django.http import HttpResponse
from rest_framework import exceptions
from rest_framework import status
from rest_framework.views import exception_handler
from rest_framework.response import Response

from common.utils import api_log

def dmp_exception_handler(exc, context):
    """
    Custom exception handler for Django Rest Framework that adds
    the `status_code` to the response.
    """
    response = exception_handler(exc, context)
    if response is not None:
        response.data['status_code'] = response.status_code
    #request = context['request']
    #view = str(context['view']).split('.')[2].split()[0]
    #operation =  context['request'].method + ' ' + view
    #if ('detail' in exc.__dict__):
    #    res = json.dumps(exc.detail).decode("unicode-escape")
    #else:
    #    res = exc
    #api_log(operation, request, res, 'ERROR')
    return response


class ExceptionMiddleware(object):
    """
    Handle all Exception except APIExceptions and ValidationError.
    """
    def process_exception(self, request, exception):
        response = json.dumps({'status_code': status.HTTP_500_INTERNAL_SERVER_ERROR,
                               'detail': str(exception)})
        return HttpResponse(response, content_type='application/json; charset=utf-8')

