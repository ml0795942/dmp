# -*- coding:utf-8 -*-
# Author: Guanxiong Liu <liuguanxiong@qiyi.com>
#         Zhenghao Zhang<zhangzhenghao@qiyi.com>

import logging
import time

from rest_framework import exceptions
from operator import attrgetter
from django.contrib.auth.models import User, Permission

import exception_info, config

from audience.models import DmpAudienceInfo
from log.models import DmpLog
from pylib import pymysql


def calPageStartEnd(page, page_size, total_count):
    try:
        page = int(page)
        page = 1 if page < 1 else page
        page_size = int(page_size)
        page_size = total_count if page_size <= 0 else page_size
    except:
        page = 1
        page_size = total_count
    start = (page - 1) * page_size
    end = start + page_size
    return (start, end)


def checkFieldExist(request, field):
    if field not in request.data or not request.data[field]:
        return False
    else:
        return True


def checkStatusField(request, type):
    status = int(request.data['status'])
    type_list = [0, 1, 2, 3]
    if type == 2:
        if status == 1 or status == 0:
            return True
        else:
            return False
    else:
        if status in type_list:
            return True
        else:
            return False


def column_order(results, sort, order):
    if (order == 'asc'):
        return sorted(results, key=attrgetter(sort), reverse=False)
    else:
        return sorted(results, key=attrgetter(sort), reverse=True)


def search_result(final_results,results, search):
    list = []
    for result in results:
        for key in result.__dict__:
            if str(result.__dict__[key]).upper().find(search.upper()) != -1:
                list.append(int(result.__dict__['id']))
                break
    return list


def res_handler(results, keys, value_convert_json):
    for result in results:
        for key in keys:
            result.__dict__[key] = value_convert_json[key][result.__dict__[key]]


# May be moved in database.
dmp_admin_name = {'liuguanxiong', 'liuguohui', 'zhangzhenghao', 'wujianjun', 'xulong', 'liushaohua', 'huangwei', 'zhangwen'}
def check_auth(request):
    if 'REMOTE_USER' not in request.META:
        raise exceptions.APIException(exception_info.PERMISSION_ERROR)
    username = request.META['REMOTE_USER']
    if username not in dmp_admin_name:
        raise exceptions.APIException(exception_info.PERMISSION_ERROR)

def add_user(request):
    if 'REMOTE_USER' not in request.META:
        raise exceptions.APIException(exception_info.PERMISSION_ERROR)
    username = request.META['REMOTE_USER']
    try:
        User.objects.get(username=username)
    except:
        user = User.objects.create_user(username=username, password='123')

def check_perm(request, perm):
    if 'REMOTE_USER' not in request.META:
        raise exceptions.APIException(exception_info.PERMISSION_ERROR)
    username = request.META['REMOTE_USER']
    user = User.objects.get(username=username)
    if not user.has_perm(perm):
        raise exceptions.APIException(exception_info.PERMISSION_ERROR)

#logger = logging.getLogger('apilog')
def api_log(operation, request, res, level):
    #detail = '[' + operation + ' by ' + request.META['REMOTE_USER'] + '] '
    #detail += str(request.data) + ' ===> ' + str(res.__dict__)
    #logger.debug(detail)
    operation = operation.split()
    log = DmpLog()
    log.user = request.META['REMOTE_USER']
    log.operation = operation[0]
    log.app = operation[1]
    log.request = request.data
    if (type(res) == unicode):
        log.response = res
    else:
        log.response = str(res.__dict__)
    log.save()


def checkAudienceIdExist(request):
    id = int(request.data['audience_target_id'])
    try:
        aud = models.DmpAudienceInfo.objects.get(id=id)
        return True
    except:
        return False

def create_audience_info(name, id_type, audience_type):
     aud = DmpAudienceInfo()
     aud.name = name
     aud.id_type = int(id_type)
     aud.id = generate_id(aud.id_type, audience_type)
     aud.audience_type = audience_type
     aud.save()
     return aud.id

def generate_id(id_type, audience_type):
    if id_type == 0:
        if audience_type == 1:
            low = 10000000
            upper = 19999999
        else:
            low = 30000000
            upper = 39999999
    else:
        if audience_type == 1:
            low = 20000000
            upper = 29999999
        else:
            low = 40000000
            upper = 49999999
    objs = DmpAudienceInfo.objects.all()
    id_list = [obj.id for obj in objs if obj.id > low and obj.id <= upper]
    if len(id_list) == 0:
        return low + 1
    else:
        return max(id_list) + 1

def audience_id_convert_name(ids):
    ids = str(ids).strip()
    id_list = ids.split(';')
    name_list = ''
    for id in id_list:
        if (id == ''):
            continue
        try:
            aud = DmpAudienceInfo.objects.all().get(id=int(id))
            name_list += aud.name + ';'
        except:
            name_list += id + ';'
    return name_list

def object_value_migrate(object_0, object_1):
    for key in object_1.__dict__:
        if (key == 'audience_target_id'):
            object_0.__dict__[key] = str(object_1.__dict__[key])
        else:
            object_0.__dict__[key] = object_1.__dict__[key]

