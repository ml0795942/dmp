# -*- coding:utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

class ErrorResponse(object):

    def __init__(self, message):
        self.message = message


class ListResponse(object):

    def __init__(self, count, page_size, results):
        self.count = count
        self.page_size = page_size
        self.results = results


class IdToken:
    def __init__(self, dsp_id, token):
        self.dsp_id = dsp_id
        self.token = token


class ReturnId:
    def __init__(self, id):
        self.id = id


class ReturnIdStatus:
    def __init__(self, id, status):
        self.id = id
        self.status = status
