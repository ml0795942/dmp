CREATE TABLE `cpc_relativity_result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `key_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `key_type` smallint(6) NOT NULL,
  `key_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `match_id` bigint(20) NOT NULL,
  `match_id_name` varchar(255) NOT NULL,
  `biz_type` varchar(30) NOT NULL,
  `match_type` varchar(10) NOT NULL,
  `match_score` float(7,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_report` (`key_id`,`match_id`) USING BTREE,
  KEY `index_match_id` (`match_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `dmp_audience_info` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end_timestamp` timestamp NOT NULL DEFAULT '2038-01-01 00:00:00',
  `id_type` tinyint(4) NOT NULL,
  `size` bigint(20) NOT NULL DEFAULT -1,
  `audience_type` tinyint(4) NOT NULL,
  `parent_id` bigint(20) NOT NULL DEFAULT -1,
  `pvalue` double NOT NULL DEFAULT -1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `dmp_task_audience_update` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `audience_target_id` bigint(20) NOT NULL,
  `hdfs_url` varchar(255) NOT NULL,
  `id_type` tinyint(4) NOT NULL,
  `threhold` double NOT NULL DEFAULT '-1',
  `expired_time` timestamp NOT NULL DEFAULT '2038-01-01 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `dmp_dsp_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `token` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `qps` int(11) NOT NULL,
  `dsp_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `dsp_id` (`dsp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `dmp_dsp_schedule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0',
  `dsp_id` bigint(20) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `audiences` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dsp_id` (`dsp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `dmp_audience_inventory` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `audience_id` bigint(20) NOT NULL,
  `daily_inventory`  bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY (`audience_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `dmp_audience_lookalike` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `audience_id` bigint(20) NOT NULL,
  `pvalue`  float(7,4) NOT NULL,
  `expect_size` int(11) NOT NULL,
  `hdfs_url` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY (`audience_id`, `pvalue`, `expect_size`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;