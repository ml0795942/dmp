# -*- coding:utf-8 -*-
# Authors: Zhenghao Zhang <zhangzhenghao@qiyi.com>
#          Guanxiong Liu <liuguanxong@qiyi.com>

import os
import sys
import time
import logging

from pylib import pyinit, pymysql, pyudf

import config

LOG = logging.getLogger()


class DBAlgoTest(pymysql.PyMysql):
    """Offline algo database in test environment."""

    def __init__(self):
        ip = config.DB_ALGO_TEST['ip']
        user = config.DB_ALGO_TEST['user']
        pwd = config.DB_ALGO_TEST['pwd']
        dbname = config.DB_ALGO_TEST['dbname']
        port = config.DB_ALGO_TEST['port']
        super(DBAlgoTest, self).__init__(ip, user, pwd, dbname, port=port)

    def dump_dmp_audience_info(self):
        sql = "select id, name, update_time, end_timestamp, id_type, size,\
            audience_type, parent_id from dmp_audience_info"
        results = self.sql(sql)
        return results

    def dump_dmp_task_audience_update(self):
        sql = "select id, status, update_time, audience_target_id, hdfs_url,\
            expired_time, priority, mv_or_cp from dmp_task_audience_update"
        results = self.sql(sql)
        return results

    def dump_dmp_dsp_info(self):
        sql = "select * from dmp_dsp_info"
        results = self.sql(sql)
        return results

    def dump_dmp_dsp_schedule(self):
        sql = "select * from dmp_dsp_schedule"
        results = self.sql(sql)
        return results

    def dump_dmp_click_retargeting(self):
        sql = "select * from dmp_click_retargeting"
        results = self.sql(sql)
        return results

    def dump_dmp_basic_profile(self):
        sql = "select * from dmp_basic_profile"
        results = self.sql(sql)
        return results

    def dump_dmp_search_words(self):
        sql = "select * from dmp_search_words"
        results = self.sql(sql)
        return results


class DBAlgo(pymysql.PyMysql):
    """Online algo database in production environment."""

    def __init__(self, is_create_tbl=False):
        self.__is_create_tbl = is_create_tbl
        ip = config.DB_ALGO['ip']
        user = config.DB_ALGO['user']
        pwd = config.DB_ALGO['pwd']
        dbname = config.DB_ALGO['dbname']
        port = config.DB_ALGO['port']
        super(DBAlgo, self).__init__(ip, user, pwd, dbname, port=port)

    def update_dmp_audience_info(self, results):
        if self.__is_create_tbl:
            self.sql(config.SQL_DMP_AUDIENCE_INFO)
        sql = 'insert ignore into dmp_audience_info (id, name, update_time,\
            end_timestamp, id_type, size, audience_type, parent_id)\
            values (%s, %s, %s, %s, %s, %s, %s, %s)'
        self.sql(sql, results)

    def update_dmp_task_audience_update(self, results):
        if self.__is_create_tbl:
            self.sql(config.SQL_DMP_TASK_AUDIENCE_UPDATE)
        sql = 'insert ignore into dmp_task_audience_update (id, status, update_time,\
            audience_target_id, hdfs_url, expired_time, priority, mv_or_cp)\
        values (%s, %s, %s, %s, %s, %s, %s, %s)'
        self.sql(sql, results)

    def update_dmp_dsp_info(self, results):
        if self.__is_create_tbl:
            self.sql(config.SQL_DMP_DSP_INFO)
        sql = 'insert ignore into dmp_dsp_info (id, name, update_time, token, status, qps, dsp_id) \
            values (%s, %s, %s, %s, %s, %s, %s)'
        self.sql(sql, results)

    def update_dmp_dsp_schedule(self, results):
        if self.__is_create_tbl:
            self.sql(config.SQL_DMP_DSP_SCHEDULE)
        sql = 'insert ignore into dmp_dsp_schedule (id, name, update_time, status, delete_flag,\
            dsp_id, start_date, end_date, audiences) \
            values (%s, %s, %s, %s, %s, %s, %s, %s, %s)'
        self.sql(sql, results)

    def update_dmp_click_retargeting(self, results):
        if self.__is_create_tbl:
            self.sql(config.SQL_DMP_CLICK_RETARGETING)
        sql = 'insert ignore into dmp_click_retargeting (id, name, audience_target_id, status,\
            update_time, order_items, type, end_date) \
            values (%s, %s, %s, %s, %s, %s, %s, %s)'
        self.sql(sql, results)

    def update_dmp_basic_file(self, results):
        if self.__is_create_tbl:
            self.sql(config.SQL_DMP_BASIC_PROFILE)
        sql = 'insert ignore into dmp_basic_profile (id, name, tag_name, tag_id,\
            audience_target_id, id_type, status, end_date) \
            values (%s, %s, %s, %s, %s, %s, %s, %s)'
        self.sql(sql, results)

    def update_dmp_search_words(self, results):
        if self.__is_create_tbl:
            self.sql(config.SQL_DMP_SEARCH_WORDS)
        sql = 'insert ignore into dmp_search_words (id, uaa_id, audience_target_id, name,\
            last_update, status, end_date, update_time) \
            values (%s, %s, %s, %s, %s, %s, %s, %s)'
        self.sql(sql, results)


class DataMigiration(object):

    def __init__(self, table, is_create_tbl):
        self.__table = table
        self.__is_create_tbl = is_create_tbl
        self.__dbalgotest = DBAlgoTest()
        self.__dbalgo = DBAlgo(is_create_tbl)

    def __transfer_dmp_audience_info(self):
        """Transfer table dmp_audience_info"""
        results = self.__dbalgotest.dump_dmp_audience_info()
        values = []
        for result in results:
            parent_id = -1 if result['parent_id'] is None else result['parent_id']
            size = -1 if result['size'] is None else result['size']
            values.append((result['id'], result['name'], result['update_time'], result['end_timestamp'],
                           result['id_type'], size, result['audience_type'], parent_id))
        self.__dbalgo.update_dmp_audience_info(values)

    def __transfer_dmp_task_audience_update(self):
        """Transfer table dmp_task_audience_update"""
        results = self.__dbalgotest.dump_dmp_task_audience_update()
        values = []
        for result in results:
            values.append((result['id'], result['status'], result['update_time'], result['audience_target_id'],
                           result['hdfs_url'], result['expired_time'], result['priority'], result['mv_or_cp']))
        self.__dbalgo.update_dmp_task_audience_update(values)

    def __transfer_dmp_dsp_info(self):
        """Transfer table dmp_dsp_info"""
        results = self.__dbalgotest.dump_dmp_dsp_info()
        values = []
        for result in results:
            values.append((result['id'], result['name'], result['update_time'], result['token'],
                           result['status'], result['qps'], result['dsp_id']))
        self.__dbalgo.update_dmp_dsp_info(values)

    def __transfer_dmp_dsp_schedule(self):
        """Transfer table dmp_dsp_schedule"""
        results = self.__dbalgotest.dump_dmp_dsp_schedule()
        values = []
        for result in results:
            values.append((result['id'], result['name'], result['update_time'], result['status'],
                           result['delete_flag'], result['dsp_id'], result['start_date'],
                           result['end_date'], result['audiences']))
        self.__dbalgo.update_dmp_dsp_schedule(values)

    def __transfer_dmp_click_retargeting(self):
        """Transfer table dmp_click_retargeting"""
        results = self.__dbalgotest.dump_dmp_click_retargeting()
        values = []
        for result in results:
            values.append((result['id'], result['name'], result['audience_target_id'], result['status'],
                           result['update_time'], result['order_items'], result['type'], result['end_date']))
        self.__dbalgo.update_dmp_click_retargeting(values)


    def __transfer_dmp_basic_profile(self):
        """Transfer table dmp_baisc_profile"""
        results = self.__dbalgotest.dump_dmp_basic_profile()
        values = []
        for result in results:
            values.append((result['id'], result['name'], result['tag_name'], result['tag_id'],
                           result['audience_target_id'], result['id_type'], result['status'], result['end_date']))
        self.__dbalgo.update_dmp_basic_file(values)

    def __transfer_dmp_search_words(self):
        """Transfer table dmp_search_words"""
        results = self.__dbalgotest.dump_dmp_search_words()
        values = []
        for result in results:
            values.append((result['id'], result['uaa_id'], result['audience_target_id'], result['name'],
                           result['last_update'], result['status'], result['end_date'], result['update_time']))
        self.__dbalgo.update_dmp_search_words(values)

    def __create_other_tables(self):
        """Create other tables including dmp_audience_schedule/dmp_lookalike/dmp_relativity_update"""
        if self.__is_create_tbl:
            self.__dbalgo.sql(config.SQL_DMP_AUDIENCE_SCHEDULE)
            self.__dbalgo.sql(config.SQL_DMP_LOOKALIKE)
            self.__dbalgo.sql(config.SQL_DMP_RELATIVITY_UPDATE)

    @pyinit.debug
    def run(self):
        if self.__table == "all":
            self.__transfer_dmp_dsp_schedule()
            self.__transfer_dmp_dsp_info()
            self.__transfer_dmp_task_audience_update()
            self.__transfer_dmp_audience_info()
            self.__transfer_dmp_click_retargeting()
            self.__transfer_dmp_basic_profile()
            self.__transfer_dmp_search_words()
            self.__create_other_tables()
        elif self.__table == config.TBL_DMP_DSP_SCHEDULE:
            self.__transfer_dmp_dsp_schedule()
        elif self.__table == config.TBL_DMP_DSP_INFO:
            self.__transfer_dmp_dsp_info()
        elif self.__table == config.TBL_DMP_TASK_AUDIENCE_UPDATE:
            self.__transfer_dmp_task_audience_update()
        elif self.__table == config.TBL_DMP_AUDIENCE_INFO:
            self.__transfer_dmp_audience_info()
        elif self.__table == config.TBL_DMP_CLICK_RETARGETING:
            self.__transfer_dmp_click_retargeting()
        elif self.__table == config.TBL_DMP_BASIC_PROFILE:
            self.__transfer_dmp_basic_profile()
        elif self.__table == config.TBL_DMP_SEARCH_WORDS:
            self.__transfer_dmp_search_words()
        else:
            LOG.error("table %s not supported." % self.__table)

if __name__ == '__main__':
    parser = pyinit.get_parser()
    parser.add_argument('-tbl', '--table',
                        type=str,
                        help='Table name need to transfer, default migrate all tables',
                        default='all',
                        action='store')
    parser.add_argument('-c', '--create',
                        help='Recreate tables',
                        default=False,
                        action='store_true')
    args = pyinit.normal_mode('dmp_api', parser=parser, daemon=True)
    LOG.info('data migration start.')
    data_migiration = DataMigiration(args.table, args.create)
    data_migiration.run()
    LOG.info('data migration end.')
