# -*- coding:utf-8 -*-
# Authors: Zhenghao Zhang <zhangzhenghao@qiyi.com>
#          Guanxiong Liu <liuguanxong@qiyi.com>

#---------------------------
# ALGO_TEST
#---------------------------
DB_ALGO_TEST = {
    'ip': 'sh.dbtest3.w.qiyi.db',
    'user': 'cupid_algo',
    'pwd': 'IUtsiu92',
    'dbname': 'cupid_algo',
    'port': 8663
}

DB_ALGO = {
    'ip': 'sh.cupidalgo.w.qiyi.db',
    'user': 'cupid_algo',
    'pwd': 'bX0KSQ1l',
    'dbname': 'cupid_algo',
    'port': 8551
}

#---------------------------
# TABLE NAME
#---------------------------
TBL_DMP_AUDIENCE_INFO = "dmp_audience_info"
TBL_DMP_TASK_AUDIENCE_UPDATE = "dmp_task_audience_update"
TBL_DMP_AUDIENCE_SCHEDULE = "dmp_audience_schedule"
TBL_DMP_DSP_INFO = "dmp_dsp_info"
TBL_DMP_DSP_SCHEDULE = "dmp_dsp_schedule"
TBL_DMP_LOOKALIKE = "dmp_lookalike"
TBL_DMP_RELATIVITY_UPDATE = "relativity_update"
TBL_DMP_CLICK_RETARGETING = "dmp_click_retargeting"
TBL_DMP_BASIC_PROFILE = "dmp_basic_profile"
TBL_DMP_SEARCH_WORDS = "dmp_search_words"

#---------------------------
# TABLE SQL
#---------------------------
SQL_DMP_AUDIENCE_INFO = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end_timestamp` timestamp NOT NULL DEFAULT '2038-01-01 00:00:00',
  `id_type` tinyint(4) NOT NULL,
  `size` bigint(20) NOT NULL DEFAULT -1,
  `audience_type` tinyint(4) NOT NULL,
  `parent_id` bigint(20) NOT NULL DEFAULT -1,
  `expect_size` bigint(20) NOT NULL DEFAULT -1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
""" % (TBL_DMP_AUDIENCE_INFO, TBL_DMP_AUDIENCE_INFO)

SQL_DMP_TASK_AUDIENCE_UPDATE = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `audience_target_id` bigint(20) NOT NULL,
  `hdfs_url` varchar(255) NOT NULL,
  `expired_time` timestamp NOT NULL DEFAULT '2038-01-01 00:00:00',
  `priority` int NOT NULL DEFAULT '100',
  `mv_or_cp` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
""" % (TBL_DMP_TASK_AUDIENCE_UPDATE, TBL_DMP_TASK_AUDIENCE_UPDATE)

SQL_DMP_AUDIENCE_SCHEDULE = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `audience_id` bigint(20) NOT NULL,
  `audience_type` tinyint(4) NOT NULL,
  `expect_size` bigint(20) NOT NULL DEFAULT -1,
  `order_items` varchar(1024) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
""" % (TBL_DMP_AUDIENCE_SCHEDULE, TBL_DMP_AUDIENCE_SCHEDULE)

SQL_DMP_DSP_INFO = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `token` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `qps` int(11) NOT NULL,
  `dsp_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `dsp_id` (`dsp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
""" % (TBL_DMP_DSP_INFO, TBL_DMP_DSP_INFO)

SQL_DMP_DSP_SCHEDULE = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0',
  `dsp_id` bigint(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `audiences` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dsp_id` (`dsp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
""" % (TBL_DMP_DSP_SCHEDULE, TBL_DMP_DSP_SCHEDULE)

SQL_DMP_LOOKALIKE = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL,
  `expect_size` int(11) NOT NULL,
  `hdfs_url` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
""" % (TBL_DMP_LOOKALIKE, TBL_DMP_LOOKALIKE)

SQL_DMP_RELATIVITY_UPDATE = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_url` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `message` varchar(255) NOT NULL DEFAULT '',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
""" % (TBL_DMP_RELATIVITY_UPDATE, TBL_DMP_RELATIVITY_UPDATE)

SQL_DMP_CLICK_RETARGETING = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `audience_target_id` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `end_date` date NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `order_items` text NOT NULL,
  `type` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
""" % (TBL_DMP_CLICK_RETARGETING, TBL_DMP_CLICK_RETARGETING)

SQL_DMP_BASIC_PROFILE = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tag_id` bigint(20) NOT NULL,
  `audience_target_id` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `end_date` date NOT NULL,
  `id_type` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `tag_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
""" % (TBL_DMP_BASIC_PROFILE, TBL_DMP_BASIC_PROFILE)

SQL_DMP_SEARCH_WORDS = """
DROP TABLE IF EXISTS `%s`;
CREATE TABLE `%s` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uaa_id` bigint(20) NOT NULL,
  `audience_target_id` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `end_date` date NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(255) NOT NULL DEFAULT '',
  `last_update` date NOT NULL DEFAULT '1980-08-08',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
""" % (TBL_DMP_SEARCH_WORDS, TBL_DMP_SEARCH_WORDS)
