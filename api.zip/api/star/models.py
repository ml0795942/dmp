# -*- coding: utf-8 -*-
# Author: Zhenghao Zhang<zhangzhenghao@qiyi.com>

from __future__ import unicode_literals

import datetime

from django.db import models


class DmpQipuPerson(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    last_updated = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'qipu_person'
