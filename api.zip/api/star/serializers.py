# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang<zhangzhenghao@qiyi.com>

from rest_framework import serializers

from common import exception_info
from models import DmpQipuPerson 

class DmpQipuPersonSerializer(serializers.ModelSerializer):

    last_updated = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)

    class Meta:
        model = DmpQipuPerson

class DmpQipuPersonListSerializer(serializers.Serializer):
    results = DmpQipuPersonSerializer(many=True)
    count = serializers.IntegerField()
    page_size = serializers.IntegerField()
