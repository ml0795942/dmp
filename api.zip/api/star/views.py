# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang<zhangzhenghao@qiyi.com>

import sys
from datetime import datetime

from django.shortcuts import render
from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import viewsets
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import exceptions

from common import exception_info
from common.exception_handler import exception_handler
from common.json_response import ListResponse, ReturnId
from common.utils import api_log, calPageStartEnd, checkFieldExist, checkStatusField, column_order, search_result, res_handler
from common.utils import check_auth, checkAudienceIdExist, create_audience_info, audience_id_convert_name, object_value_migrate
from models import DmpQipuPerson
from serializers import DmpQipuPersonSerializer, DmpQipuPersonListSerializer

class DmpQipuPersonView(viewsets.ViewSet):

    def list(self, request, format=None):
        add_user(request)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        results = DmpQipuPerson.objects.all().using('person').order_by('-id')
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            results = DmpQipuPerson.objects.using('person').filter(name__contains=search)
        #results = column_order(results, sort, order)
        count = 2000
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = DmpQipuPersonListSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)
