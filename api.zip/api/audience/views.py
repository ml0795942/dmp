# -*- coding:utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

import sys
from datetime import datetime

from django.shortcuts import render
from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import viewsets
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import exceptions

from common import exception_info
from common.exception_handler import exception_handler
from common.json_response import ListResponse, ReturnId
from common.utils import calPageStartEnd, checkFieldExist, checkStatusField, column_order, search_result, res_handler, generate_id
from common.utils import api_log, check_auth, audience_id_convert_name, object_value_migrate, add_user, check_perm
from models import DmpAudienceInfo, DmpTaskAudienceUpdate, DmpAudienceSchedule, DmpTaskAudienceUpdateConvert
from dsp.models import DmpDspSchedule
from serializers import DmpAudienceInfoListResponseSerializer
from serializers import DmpTaskAudienceUpdateListResponseSerializer
from serializers import DmpAudienceInfoSerializer
from serializers import DmpAudienceIdResponseSerializer
from serializers import DmpTaskAudienceUpdateSerializer
from serializers import DmpAudienceScheduleListResponseSerializer
from serializers import DmpAudienceScheduleSerializer


class DmpAudienceInfoView(viewsets.ViewSet):

    def create(self, request, format=None):
        check_auth(request)
        check_perm(request, 'audience.add_dmpaudienceinfo')
        serializer = DmpAudienceInfoSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        # build model
        aud = DmpAudienceInfo()
        aud.name = request.data['name']
        aud.id_type = int(request.data['id_type'])
        aud.audience_type = int(request.data['audience_type'])
        if checkFieldExist(request, 'parent_id'):
            aud.parent_id = int(request.data['parent_id'])
        if checkFieldExist(request, 'expect_size'):
            aud.expect_size = int(request.data['expect_size'])
        aud.id = generate_id(aud.id_type, aud.audience_type)
        aud.save()
        response_id = ReturnId(aud.id)
        serializer_context = {
            'request': Request(request),
        }
        res = DmpAudienceIdResponseSerializer(instance=response_id, context=serializer_context)
        api_log('POST DmpAudienceInfoView', request, aud, 'DEBUG')
        return Response(res.data)

    def list(self, request, format=None):
        add_user(request)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        results = DmpAudienceInfo.objects.all()
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            value_convert_json = {
                'id_type' : {0 : 'cupid_user_id',1 : 'uaa_user_id'},
                'audience_type' : {1 : '基础人群',2 : '组合人群',3 : '第三方人群',4 : '扩展人群',5 : '搜索词包人群',6 : '点击追投人群', 7: '明星粉丝人群', 8 : '追剧人群'}}
            keys = ['id_type', 'audience_type']
            temp_results = results
            res_handler(temp_results, keys, value_convert_json)
            list = search_result(results,temp_results, search)
            results = DmpAudienceInfo.objects.filter(id__in=list)
        results = column_order(results, sort, order)
        count = len(results)
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = DmpAudienceInfoListResponseSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)

    def put(self, request, pk=None, format=None):
        check_auth(request)
        check_perm(request, 'audience.change_dmpaudienceinfo')
        if not checkFieldExist(request, 'id'):
            raise exceptions.APIException(exception_info.ID_REQUIRED)
        try:
            aud = DmpAudienceInfo.objects.get(id=request.data['id'])
        except DmpAudienceInfo.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        # fill model
        if checkFieldExist(request, 'end_timestamp'):
            aud.end_timestamp = request.data['end_timestamp']
        if checkFieldExist(request, 'size'):
            aud.size = request.data['size']
        aud.save()
        serializer_context = {
            'request': Request(request),
        }
        res = DmpAudienceInfoSerializer(instance=aud, context=serializer_context)
        api_log('PUT DmpAudienceInfoView', request, aud, 'DEBUG')
        return Response(res.data)


class DmpTaskAudienceUpdateView(viewsets.ViewSet):

    def create(self, request, format=None):
        check_auth(request)
        check_perm(request, 'audience.add_dmptaskaudienceupdate')
        serializer = DmpTaskAudienceUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        update_task = DmpTaskAudienceUpdate()
        update_task.audience_target_id = request.data['audience_target_id']
        if checkFieldExist(request, 'expired_time'):
            update_task.expired_time = request.data['expired_time']
        try:
            aud = DmpAudienceInfo.objects.get(id=update_task.audience_target_id)
            update_task.id_type = aud.id_type
        except DmpAudienceInfo.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        update_task.hdfs_url = request.data['hdfs_url']
        update_task.save()
        response_id = ReturnId(update_task.id)
        serializer_context = {
            'request': Request(request),
        }
        res = DmpAudienceIdResponseSerializer(instance=response_id, context=serializer_context)
        api_log('POST DmpTaskAudienceUpdateView', request, update_task, 'DEBUG')
        return Response(res.data)

    def list(self, request, format=None):
        add_user(request)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        results = DmpTaskAudienceUpdate.objects.all().order_by('-id')
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            value_convert_json = {
                'status' : {0 : '待更新',1 : '更新中',2 : '成功',3 : '失败',},
                'id_type' : {0 : 'cupid_user_id',1 : 'uaa_user_id',}}
            keys = ['status', 'id_type']
            temp_results = results
            res_handler(temp_results, keys, value_convert_json)
            list = search_result(results,temp_results, search)
            results = DmpTaskAudienceUpdate.objects.filter(id__in=list)
	results_convert = []
	for result in results:
	    result_convert = DmpTaskAudienceUpdateConvert()
	    object_value_migrate(result_convert, result)
	    result_convert.audience_name = audience_id_convert_name(result.audience_target_id)
	    results_convert.append(result_convert)
        results_convert = column_order(results_convert, sort, order)
        count = len(results_convert)
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results_convert[start:end]

        #convert_results = []
        #results = page_results
        #for result in results:
        #    task = DmpTaskAudienceUpdateConvert()
        #    object_value_migrate(task, result)
        #    convert_results.append(task)
        #for result in convert_results:
        #        result.audience_target_id = audience_id_convert_name(result.audience_target_id).strip(';')
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = DmpTaskAudienceUpdateListResponseSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)

    def put(self, request, pk=None, format=None):
        check_auth(request)
        check_perm(request, 'audience.change_dmptaskaudienceupdate')
        if not checkFieldExist(request, 'id'):
            raise exceptions.APIException(exception_info.ID_REQUIRED)
        try:
            task = DmpTaskAudienceUpdate.objects.get(id=request.data['id'])
        except DmpTaskAudienceUpdate.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        # fill model
        if checkFieldExist(request, 'status'):
            if not checkStatusField(request, 4):
                raise exceptions.APIException(exception_info.STATUS_OUT_OF_RANGE_4)
            task.status = request.data['status']
        task.save()
        serializer_context = {
            'request': Request(request),
        }
        res = DmpTaskAudienceUpdateSerializer(instance=task, context=serializer_context)
        api_log('PUT DmpTaskAudienceUpdateView', request, task, 'DEBUG')
        return Response(res.data)


class DmpAudienceScheduleView(viewsets.ViewSet):

    def create(self, request, format=None):
        check_auth(request)
        check_perm(request, 'audience.add_dmpaudienceschedule')
        serializer = DmpAudienceScheduleSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        schedule = DmpAudienceSchedule()
        schedule.name = request.data['name']
        schedule.audience_id = request.data['audience_id']
        try:
            aud = DmpAudienceInfo.objects.get(id=schedule.audience_id)
            schedule.audience_type = aud.audience_type
        except DmpAudienceInfo.DoesNotExist:
            raise exceptions.APIException(exception_info.AUDIENCE_ID_NOT_EXIST)
        schedule.order_items = request.data['order_items']
        schedule.start_date = request.data['start_date']
        schedule.end_date = request.data['end_date']
        schedule.save()
        response_id = ReturnId(schedule.id)
        serializer_context = {
            'request': Request(request),
        }
        res = DmpAudienceIdResponseSerializer(instance=response_id, context=serializer_context)
        api_log('POST DmpAudienceScheduleView', request, schedule, 'DEBUG')
        return Response(res.data)

    def list(self, request, format=None):
        add_user(request)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        type = request.query_params.get('type', 'ALL')
        if type == 'ALL':
            results = DmpAudienceSchedule.objects.all()
        elif type == 'LOOKALIKE_UPDATE':
            results = DmpAudienceSchedule.objects.filter(audience_type=4, status=1, end_date__gte=datetime.now())
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            results = search_result(results, search)
        results = column_order(results, sort, order)
        count = len(results)
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = DmpAudienceScheduleListResponseSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)

    def put(self, request, pk=None, format=None):
        check_auth(request)
        check_perm(request, 'audience.change_dmpaudienceschedule')
        if not checkFieldExist(request, 'id'):
            raise exceptions.APIException(exception_info.ID_REQUIRED)
        try:
            schedule = DmpAudienceSchedule.objects.get(id=request.data['id'])
        except DmpAudienceSchedule.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        # fill model
        if checkFieldExist(request, 'name'):
            schedule.name = request.data['name']
        if checkFieldExist(request, 'audience_id'):
            schedule.audience_id = request.data['audience_id']
            try:
                aud = DmpAudienceInfo.objects.get(id=schedule.audience_id)
                schedule.audience_type = aud.audience_type
            except DmpAudienceInfo.DoesNotExist:
                raise exceptions.APIException(exception_info.AUDIENCE_ID_NOT_EXIST)
        if checkFieldExist(request, 'order_items'):
            schedule.order_items = request.data['order_items']
        if checkFieldExist(request, 'start_date'):
            schedule.start_date = request.data['start_date']
        if checkFieldExist(request, 'end_date'):
            schedule.end_date = request.data['end_date']
        if checkFieldExist(request, 'status'):
            if not checkStatusField(request, 2):
                raise exceptions.APIException(exception_info.STATUS_OUT_OF_RANGE_2)
            schedule.status = request.data['status']
        schedule.save()
        res_instance = DmpAudienceSchedule.objects.get(id=request.data['id'])
        serializer_context = {
            'request': Request(request),
        }
        res = DmpAudienceScheduleSerializer(instance=res_instance, context=serializer_context)
        api_log('PUT DmpAudienceScheduleView', request, schedule, 'DEBUG')
        return Response(res.data)
