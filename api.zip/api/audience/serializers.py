# -*- coding: utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

from rest_framework import serializers

from common import exception_info
from models import DmpAudienceInfo 
from models import DmpTaskAudienceUpdate 
from models import DmpAudienceSchedule


class DmpAudienceInfoSerializer(serializers.ModelSerializer):
    end_timestamp = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)

    class Meta:
        model = DmpAudienceInfo

    def validate_id_type(self, value):
        id_type = int(value)
        if not (id_type == 1 or id_type == 0):
            raise serializers.ValidationError(exception_info.AUDIENCE_ID_TYPE_RANGE)

    def validate_audience_type(self, value):
        aud_type = int(value)
        if aud_type < 1 or aud_type > 8: 
            raise serializers.ValidationError(exception_info.AUDIENCE_TYPE_RANGE)
              

class DmpAudienceInfoListResponseSerializer(serializers.Serializer):
    results = DmpAudienceInfoSerializer(many=True)
    count = serializers.IntegerField()
    page_size = serializers.IntegerField()


class DmpAudienceIdResponseSerializer(serializers.Serializer):
    id = serializers.IntegerField()


class DmpTaskAudienceUpdateSerializer(serializers.ModelSerializer):
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    expired_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None)
    id_type = serializers.IntegerField(required=False)
    audience_target_id = serializers.IntegerField(required=False)

    class Meta:
        model = DmpTaskAudienceUpdate


class DmpTaskAudienceUpdateConvertSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    status = serializers.IntegerField()
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    expired_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None)
    id_type = serializers.IntegerField(required=False)
    audience_target_id = serializers.CharField()
    audience_name = serializers.CharField()
    hdfs_url = serializers.CharField()
    priority = serializers.IntegerField()
    mv_or_cp = serializers.IntegerField()


class DmpTaskAudienceUpdateListResponseSerializer(serializers.Serializer):
    results = DmpTaskAudienceUpdateConvertSerializer(many=True)
    count = serializers.IntegerField()
    page_size = serializers.IntegerField()


class DmpAudienceScheduleSerializer(serializers.ModelSerializer):
    create_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)

    class Meta:
        model = DmpAudienceSchedule


class DmpAudienceScheduleListResponseSerializer(serializers.Serializer):
    results = DmpAudienceScheduleSerializer(many=True)
    count = serializers.IntegerField()
    page_size = serializers.IntegerField()
