# -*- coding: utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

from __future__ import unicode_literals

from django.db import models


class DmpAudienceInfo(models.Model):
    # default for ignore validation error
    id = models.BigIntegerField(primary_key=True, default='123')
    name = models.CharField(max_length=255)
    update_time = models.DateTimeField(auto_now=True)
    end_timestamp = models.DateTimeField(default='2038-01-01 00:00:00')
    id_type = models.SmallIntegerField()
    size = models.BigIntegerField(default='-1')
    audience_type = models.SmallIntegerField()
    parent_id = models.BigIntegerField(default='-1')
    expect_size = models.BigIntegerField(default='-1')

    class Meta:
        db_table = 'dmp_audience_info'


class DmpTaskAudienceUpdate(models.Model):
    id = models.AutoField(primary_key=True)
    status = models.SmallIntegerField(default='0')
    update_time = models.DateTimeField(auto_now=True)
    audience_target_id = models.BigIntegerField()
    hdfs_url = models.CharField(max_length=255)
    id_type = models.SmallIntegerField()
    expired_time = models.DateTimeField(default='2038-01-01 00:00:00')
    priority = models.SmallIntegerField(default='100')
    mv_or_cp = models.SmallIntegerField(default='0')

    class Meta:
        db_table = 'dmp_task_audience_update'


class DmpTaskAudienceUpdateConvert(models.Model):
    id = models.AutoField(primary_key=True)
    status = models.SmallIntegerField(default='0')
    update_time = models.DateTimeField(auto_now=True)
    audience_name = models.TextField(default='NA')
    audience_target_id = models.TextField()
    hdfs_url = models.CharField(max_length=255)
    id_type = models.SmallIntegerField()
    expired_time = models.DateTimeField(default='2038-01-01 00:00:00')
    priority = models.SmallIntegerField(default='100')
    mv_or_cp = models.SmallIntegerField(default='0')


class DmpAudienceSchedule(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    audience_id = models.BigIntegerField()
    # default for ignore validation error
    audience_type = models.SmallIntegerField(default='-1')
    expect_size = models.BigIntegerField(default='-1')
    order_items = models.CharField(max_length=255)
    start_date = models.DateField()
    end_date = models.DateField()
    status = models.SmallIntegerField(default='0')
    create_time = models.DateTimeField(auto_now_add=True)
    update_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dmp_audience_schedule'
