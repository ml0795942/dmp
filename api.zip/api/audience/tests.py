# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang <zhangzhenghao@qiyi.com>

from django.test import TestCase
from rest_framework.test import APITestCase
from rest_framework.test import APIRequestFactory

from models import DmpAudienceInfo, DmpTaskAudienceUpdate, DmpAudienceSchedule
from common import exception_info

INFO_URL = '/audience/'
TASK_URL = '/audience/task/'
SCHEDULE_URL = '/audience/schedule/'

INFO_DATA = {'name': 'aaa', 'id_type': 1, 'audience_type': 1, 'parent_id': 123, 'expect_size': 123}
TASK_DATA = {'audience_target_id': 20000001, 'expired_time': '2016-03-28 16:24:27', 'hdfs_url': '/asdf/asdf'}
SCHEDULE_DATA = {'audience_id': 20000001, 'name': 'zzz', 'order_items': 'asdf', 'start_date': '2016-03-28', 'end_date': '2016-03-28'}


class AudienceTest(APITestCase):

    def test_create_audience(self):
        data = {'name': 'aaa'}
        response = self.client.post(INFO_URL, data, format='json')
        self.assertEquals(response.status_code, 400)
        data = {'name': 'aaa', 'id_type': 2, 'audience_type': 7, 'parent_id': 123, 'expect_size': 123}
        response = self.client.post(INFO_URL, data, format='json')
        self.assertContains(response, '"audience_type":["只能取1~6之间的整数值"],"id_type":["只能取0或1"]', status_code=400)
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        self.assertEquals(DmpAudienceInfo.objects.count(), 1)
        self.assertEquals(DmpAudienceInfo.objects.get(name='aaa').id_type, 1)
        self.assertEquals(DmpAudienceInfo.objects.get(name='aaa').id, 20000001)

    def test_get_audience(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.get(INFO_URL)
        self.assertEquals(DmpAudienceInfo.objects.count(), 1)

    def test_update_audience_except(self):
        data = {'id': '100', 'size':'asdf', 'end_timestamp': '2016-03-28 16:24:27'}
        response = self.client.put(INFO_URL, data, format='json')
        self.assertContains(response, exception_info.ID_NOT_EXIST, status_code=500)
        data = {'size':'asdf', 'end_timestamp': '2016-03-28 16:24:27'}
        response = self.client.put(INFO_URL, data, format='json')
        self.assertContains(response, exception_info.ID_REQUIRED, status_code=500)

    def test_update_audience(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        data = {'id': '20000001', 'size':'100'}
        response = self.client.put(INFO_URL, data, format='json')
        self.assertEquals(DmpAudienceInfo.objects.get(name='aaa').size, 100)


class AudienceTaskUpdateTest(APITestCase):

    def test_create_audience(self):
        data = {'audience_target_id': 'aaa'}
        response = self.client.post(TASK_URL, data, format='json')
        self.assertEquals(response.data, {"audience_target_id":["请填写合法的整数值。"],"hdfs_url":["该字段是必填项。"],"expired_time":["该字段是必填项。"],"status_code":400})
        response = self.client.post(TASK_URL, TASK_DATA, format='json')
        self.assertContains(response, exception_info.ID_NOT_EXIST, status_code=500)
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(TASK_URL, TASK_DATA, format='json')
        self.assertEquals(DmpTaskAudienceUpdate.objects.get(audience_target_id=20000001).hdfs_url, '/asdf/asdf')

    def test_get_task_audience(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(TASK_URL, TASK_DATA, format='json')
        response = self.client.get(TASK_URL)
        self.assertEquals(DmpTaskAudienceUpdate.objects.count(), 1)

    def test_update_task_audience_except(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(TASK_URL, TASK_DATA, format='json')
        data = {'id': '2', 'status': 3}
        response = self.client.put(TASK_URL, data, format='json')
        self.assertContains(response, exception_info.ID_NOT_EXIST, status_code=500)
        data = {'status': 3}
        response = self.client.put(TASK_URL, data, format='json')
        self.assertContains(response, exception_info.ID_REQUIRED, status_code=500)
        data = {'id': '1', 'status': 5}
        response = self.client.put(TASK_URL, data, format='json')
        self.assertContains(response, "Status只能为0,1,2,3", status_code=500)

    def test_update_task_audience(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(TASK_URL, TASK_DATA, format='json')
        data = {'id': '1', 'status': '3'}
        response = self.client.put(TASK_URL, data, format='json')
        self.assertEquals(DmpTaskAudienceUpdate.objects.get(id=1).status, 3)


class AudienceScheduleTest(APITestCase):

    def test_create_schedule(self):
        data = {'audience_id': 'aaa'}
        response = self.client.post(SCHEDULE_URL, data, format='json')
        self.assertEquals(response.status_code, 400)
        self.assertEquals(response.data,{"audience_id":["请填写合法的整数值。"],"name":["该字段是必填项。"],\
            "end_date":["该字段是必填项。"],"order_items":["该字段是必填项。"],"start_date":["该字段是必填项。"],"status_code":400})
        data = {'audience_id': 123, 'name': 'zzz', 'order_items': 'asdf', 'start_date': '2016-03-28', 'end_date': '2016-03-28'}
        response = self.client.post(SCHEDULE_URL, data, format='json')
        self.assertContains(response, 'audience_id不存在',status_code=500)
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(SCHEDULE_URL, SCHEDULE_DATA, format='json')
        self.assertEquals(DmpAudienceSchedule.objects.get(audience_id=20000001).name, 'zzz')

    def test_get_schedule(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(SCHEDULE_URL, SCHEDULE_DATA, format='json')
        response = self.client.get(SCHEDULE_URL)
        self.assertEquals(DmpAudienceSchedule.objects.count(), 1)
        self.assertEquals(DmpAudienceSchedule.objects.get(audience_id=20000001).name, 'zzz')
        response = self.client.get(SCHEDULE_URL,{'type': 'LOOKALIKE_UPDATE'})
        self.assertEquals(response.data, {'count': 0, 'results': [], 'page_size': -1})

    def test_put_schedule_except(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(SCHEDULE_URL, SCHEDULE_DATA, format='json')
        data = {'id': '2', 'status': 3}
        response = self.client.put(SCHEDULE_URL, data, format='json')
        self.assertContains(response, exception_info.ID_NOT_EXIST, status_code=500)
        data = {'status': 3}
        response = self.client.put(SCHEDULE_URL, data, format='json')
        self.assertContains(response, exception_info.ID_REQUIRED, status_code=500)
        data = {'id': '1', 'status': 5}
        response = self.client.put(SCHEDULE_URL, data, format='json')
        self.assertContains(response, "Status只能为0或1", status_code=500)
        data = {'id': '1', 'audience_id': 20000001, 'name': 'zzz', 'order_items': 'asdf', 'start_date': '123', 'end_date': '2016-03-28'}
        response = self.client.put(SCHEDULE_URL, data, format='json')
        self.assertContains(response, 'It must be in YYYY-MM-DD format.', status_code=200)

    def test_put_schedule(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(SCHEDULE_URL, SCHEDULE_DATA, format='json')
        data = {'id':1, 'audience_id': 20000001, 'name': 'xxx', 'order_items': 'asdf'}
        response = self.client.put(SCHEDULE_URL, data, format='json')
        self.assertEquals(DmpAudienceSchedule.objects.get(id=1).name, 'xxx')
