# -*- coding:utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#         Zhenghao Zhang<zhangzhenghao@qiyi.com>


from rest_framework import serializers

from common import exception_info
from models import DmpSearchWords

class DmpSearchWordsSerializer(serializers.ModelSerializer):
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    end_date = serializers.DateField(format=None, input_formats=None)

    class Meta:
        model = DmpSearchWords

    def validate_status(self, value):
        status = int(value)
        if not (status == 1 or status == 0 or status == 2 or status == -1):
            raise serializers.ValidationError(exception_info.STATUS_OUT_OF_RANGE_1)

    def validate_couchbase_flag(self, value):
        couchbase_flag = int(value)
        if not (couchbase_flag == 0 or couchbase_flag == 1 or couchbase_flag == 2):
            raise serializers.ValidationError(exception_info.COUCHBASE_FLAG_EXCEPTION)


class DmpSearchWordsConvertSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    uaa_id = serializers.IntegerField()
    audience_target_id = serializers.CharField()
    status = serializers.IntegerField()
    end_date = serializers.DateField()
    name = serializers.CharField()
    couchbase_flag = serializers.IntegerField()
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)


    def validate_status(self, value):
        status = int(value)
        if not (status == 1 or status == 0 or status == 2 or status == -1):
            raise serializers.ValidationError(exception_info.STATUS_OUT_OF_RANGE_1)

    def validate_couchbase_flag(self, value):
        couchbase_flag = int(value)
        if not (couchbase_flag == 0 or couchbase_flag == 1 or couchbase_flag == 2):
            raise serializers.ValidationError(exception_info.COUCHBASE_FLAG_EXCEPTION)


class DmpSearchWordsListSerializer(serializers.Serializer):
    results = DmpSearchWordsSerializer(many=True)
    count = serializers.IntegerField()
    page_size = serializers.IntegerField()


class DmpSearchWordsCheckSerializer(serializers.Serializer):
    name = serializers.CharField()
    cid_or_uid = serializers.IntegerField()
    uaa_id = serializers.IntegerField()
    audience_type = serializers.IntegerField()

    def validate_couchbase_flag(self, value):
        couchbase_flag = int(value)
        if not (couchbase_flag == 0 or couchbase_flag == 1 or couchbase_flag == 2):
            raise serializers.ValidationError(exception_info.COUCHBASE_FLAG_EXCEPTION)

class DmpSearchWordsEndDateConvertSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    end_date = serializers.CharField()

class DmpOpenUaaListSerializer(serializers.Serializer):
    code = serializers.CharField(default='success')
    data = DmpSearchWordsEndDateConvertSerializer(many=True)
    msg = serializers.CharField(default='success')
