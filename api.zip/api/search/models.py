# -*- coding:utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#         Zhenghao Zhang<zhangzhenghao@qiyi.com>


from __future__ import unicode_literals

import datetime

from django.db import models


class DmpSearchWords(models.Model):
    id = models.AutoField(primary_key=True)
    uaa_id = models.BigIntegerField()
    audience_target_id = models.BigIntegerField()
    status = models.SmallIntegerField(default='0')
    end_date = models.DateField(default=datetime.date.today()+datetime.timedelta(days=30))
    update_time = models.DateTimeField(auto_now=True)
    name = models.CharField(max_length=255)
    couchbase_flag = models.SmallIntegerField(default='2')

    class Meta:
        db_table = 'dmp_search_words'


class DmpSearchWordsConvert(models.Model):
    id = models.AutoField(primary_key=True)
    uaa_id = models.BigIntegerField()
    audience_target_id = models.CharField(max_length=255)
    status = models.SmallIntegerField(default='0')
    end_date = models.DateField(default=datetime.date.today()+datetime.timedelta(days=30))
    update_time = models.DateTimeField(auto_now=True)
    name = models.CharField(max_length=255)
    couchbase_flag = models.SmallIntegerField(default='2')

class DmpSearchWordsEndDate(models.Model):
    uaa_id = models.IntegerField()
    end_date = models.CharField(max_length=255)
    status = models.SmallIntegerField()

    class Meta:
        db_table = 'dmp_search_words'

class RetVal(object):

    def __init__(self, id, end_date):
        self.id = id
        self.end_date = end_date

class ListRecord(object):

    def __init__(self, code, data, msg):
        self.code = code
        self.data = data
        self.msg = msg
