# -*- coding:utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#         Zhenghao Zhang<zhangzhenghao@qiyi.com>

import sys
from datetime import datetime

from django.shortcuts import render
from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import viewsets
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import exceptions

from common import exception_info
from common.exception_handler import exception_handler
from common.json_response import ListResponse, ReturnId
from common.utils import api_log, calPageStartEnd, checkFieldExist, checkStatusField, column_order, search_result, res_handler, check_auth, checkAudienceIdExist, create_audience_info, audience_id_convert_name, object_value_migrate, add_user, check_perm
from models import DmpSearchWords, DmpSearchWordsConvert, DmpSearchWordsEndDate, RetVal, ListRecord
from serializers import DmpSearchWordsSerializer, DmpSearchWordsListSerializer, DmpSearchWordsCheckSerializer, DmpOpenUaaListSerializer
from audience.serializers import DmpAudienceIdResponseSerializer


class DmpSearchWordsView(viewsets.ViewSet):

    def create(self, request, format=None):
        check_auth(request)
        check_perm(request, 'search.add_dmpsearchwords')
        serializer = DmpSearchWordsCheckSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        name = request.data['name']
        cid_or_uid = 0
        audience_type = request.data['audience_type']
        id = create_audience_info(name, cid_or_uid, audience_type)
        search = DmpSearchWords()
        search.uaa_id = request.data['uaa_id']
        search.audience_target_id = id
        search.name = name
        search.save()
        response_id = ReturnId(id)
        serializer_context = {
            'request': Request(request),
        }
        res = DmpAudienceIdResponseSerializer(instance=response_id, context=serializer_context)
        api_log('POST DmpSearchWordsView', request, search, 'DEBUG')
        return Response(res.data)

    def list(self, request, format=None):
        add_user(request)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        results = DmpSearchWords.objects.all().order_by('-id')
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            value_convert_json = {'status' : {0 : '创建待例行化',1 : '例行化中',2 : '停止更新','-1' : '出错；需要再次例行化'},'couchbase_flag' : {0 : '不写入',1 : 'copy',2 : 'move',}}
            keys = ['status', 'couchbase_flag']
            temp_results = results
            res_handler(temp_results, keys, value_convert_json)
            list = search_result(results,temp_results, search)
            results = DmpSearchWords.objects.filter(id__in=list)
        results = column_order(results, sort, order)
        count = len(results)
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        convert_results = []
        #results = page_results
        #for result in results:
        #    task = DmpSearchWordsConvert()
        #    object_value_migrate(task, result)
        #    convert_results.append(task)
        #for result in convert_results:
        #    result.audience_target_id = audience_id_convert_name(result.audience_target_id).strip(';')
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = DmpSearchWordsListSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)

    def put(self, request, pk=None, format=None):
        check_auth(request)
        check_perm(request, 'search.change_dmpsearchwords')
        if not checkFieldExist(request, 'id'): raise exceptions.APIException(exception_info.ID_REQUIRED)
        try:
            search = DmpSearchWords.objects.get(id=request.data['id'])
        except DmpSearchWords.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        if checkFieldExist(request, 'name'):
            search.name = request.data['name']
        if checkFieldExist(request, 'uaa_id'):
            search.uaa_id = request.data['uaa_id']
        if checkFieldExist(request, 'end_date'):
            search.end_date = request.data['end_date']
        if checkFieldExist(request, 'couchbase_flag'):
            search.couchbase_flag = request.data['couchbase_flag']
        if checkFieldExist(request, 'status'):
            search.status = request.data['status']
        search.save()
        serializer_context = {
            'request': Request(request),
        }
        res = DmpSearchWordsSerializer(instance=search, context=serializer_context)
        api_log('PUT DmpSearchWordsView', request, search, 'DEBUG')
        return Response(res.data)


class DmpOpenUaaView(viewsets.ViewSet):

    def list(self, request, format=None):
        add_user(request)
        try:
            results = DmpSearchWordsEndDate.objects.all()
            records = {}
            for result in results:
                if result.status < 2:
                    uaa_id = result.uaa_id
                    if result.uaa_id in records.keys():
                        records[uaa_id] = max(records[uaa_id],result.end_date.strftime('%Y-%m-%d'))
                    else:
                        records[uaa_id] = result.end_date.strftime('%Y-%m-%d')
            final_records = [RetVal(id, records[id]) for id in records.keys()]
            ret_instance = ListRecord("success",final_records,"请求成功")
            res = DmpOpenUaaListSerializer(instance=ret_instance)
        except Exception as e:
            res = Response(str(e))
        return Response(res.data)


