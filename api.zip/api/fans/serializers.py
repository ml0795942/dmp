# -*- coding:utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

from rest_framework import serializers

from common import exception_info
from models import DmpVideoFans

class DmpVideoFansSerializer(serializers.ModelSerializer):

    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    ext_info = serializers.CharField(required=False)
    end_date = serializers.DateField(format=None, input_formats=None)
 
    class Meta:
        model = DmpVideoFans

    def validate_type(self, value):
        type = int(value)
        if not (type == 1 or type == 0):
            raise serializers.ValidationError(exception_info.TYPE_OF_CLICK_RETARGETING)


class DmpVideoFansConvertSerializer(serializers.Serializer):

    id = serializers.IntegerField()
    name = serializers.CharField()
    audience_target_id = serializers.CharField()
    freq = serializers.IntegerField()
    history_days = serializers.IntegerField()
    episodes = serializers.CharField()
    end_date = serializers.DateField()
    couchbase_flag = serializers.IntegerField()
    cid_or_uid = serializers.IntegerField()
    type = serializers.IntegerField()
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    ext_info = serializers.CharField(required=False)
    

    def validate_type(self, value):
        type = int(value)
        if not (type == 1 or type == 0):
            raise serializers.ValidationError(exception_info.TYPE_OF_CLICK_RETARGETING)


class DmpVideoFansListSerializer(serializers.Serializer):
    results = DmpVideoFansSerializer(many=True)
    count = serializers.IntegerField()
    page_size = serializers.IntegerField()


class DmpFansCheckSerializer(serializers.Serializer):
    name = serializers.CharField()
    cid_or_uid = serializers.IntegerField()
    couchbase_flag = serializers.IntegerField()
    type = serializers.IntegerField()
    audience_type = serializers.IntegerField()
    freq = serializers.IntegerField()
    episodes = serializers.CharField()
