# -*- coding:utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#         Zhenghao Zhang<zhangzhenghao@qiyi.com>

import sys
from datetime import datetime

from django.shortcuts import render
from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import viewsets
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import exceptions

from common import exception_info
from common.exception_handler import exception_handler
from common.json_response import ListResponse, ReturnId
from common.utils import api_log, calPageStartEnd, checkFieldExist, checkStatusField, column_order, search_result, res_handler
from common.utils import check_auth, checkAudienceIdExist, create_audience_info, audience_id_convert_name, object_value_migrate, check_perm, add_user
from models import DmpVideoFans, DmpVideoFansConvert
from serializers import DmpVideoFansSerializer, DmpVideoFansListSerializer, DmpFansCheckSerializer
from mysql_process import DBAlgoBusiness
from audience.serializers import DmpAudienceIdResponseSerializer


class DmpVideoFansView(viewsets.ViewSet):

    def create(self, request, format=None):
        check_auth(request)
        check_perm(request, 'fans.add_dmpvideofans')
        serializer = DmpFansCheckSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        name = request.data['name']
        cid_or_uid = request.data['cid_or_uid']
        audience_type = request.data['audience_type']
        id = create_audience_info(name, cid_or_uid, audience_type)
        fans = DmpVideoFans()
        fans.name = name
        fans.type = int(request.data['type'])
        fans.freq = request.data['freq']
        fans.couchbase_flag = request.data['couchbase_flag']
        fans.cid_or_uid = request.data['cid_or_uid']
        fans.audience_target_id = id
        if (fans.type == 0):
            album_episodes = request.data['episodes']
            episode = DBAlgoBusiness()
            list = episode.list_name(album_episodes, 0)
            if (list[1] > 5000):
                raise exceptions.APIException(exception_info.TOO_MUCH_EPISODES)
            fans.episodes = list[0]
        else:
            star_episodes = request.data['episodes']
            episode = DBAlgoBusiness()
            list = episode.list_name(star_episodes, 1)
            if (list[2] > 5000):
                raise exceptions.APIException(exception_info.TOO_MUCH_EPISODES)
            if (len(list[0]) == 0):
                raise exceptions.APIException("没找到明星%s相关剧集"%(star_episodes))
            fans.episodes = list[1]
            fans.ext_info = list[0]
        fans.save()
        response_id = ReturnId(id)
        serializer_context = {
            'request': Request(request),
        }
        res = DmpAudienceIdResponseSerializer(instance=response_id, context=serializer_context)
        #api_log('CREATE VIDEO_FANS', request, fans, 'DEBUG')
        api_log('POST DmpVideoFansView', request, fans, 'DEBUG')
        return Response(res.data)

    def list(self, request, format=None):
        add_user(request)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        type = request.query_params.get('type')
        results = DmpVideoFans.objects.all().filter(type=type).order_by('-id')
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            value_convert_json = {'cid_or_uid' : {0 : 'cupid_user_id',1 : 'uaa_user_id',},\
                'couchbase_flag' : {0 : '不写入', 1 : 'copy', 2 : 'move',}}
            keys = ['cid_or_uid', 'couchbase_flag']
            temp_results = results
            res_handler(temp_results, keys, value_convert_json)
            list = search_result(results,temp_results, search)
            results = DmpVideoFans.objects.filter(id__in=list)
        results = column_order(results, sort, order)
        count = len(results)
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        #convert_results = []
        #results = page_results
        #for result in results:
        #    task = DmpVideoFansConvert()
        #    object_value_migrate(task, result)
        #    convert_results.append(task)
        #for result in convert_results:
        #    result.audience_target_id = audience_id_convert_name(result.audience_target_id).strip(';')
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = DmpVideoFansListSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)

    def put(self, request, pk=None, format=None):
        check_auth(request)
        check_perm(request, 'fans.change_dmpvideofans')
        if not checkFieldExist(request, 'id'): raise exceptions.APIException(exception_info.ID_REQUIRED)
        try:
            fans = DmpVideoFans.objects.get(id=request.data['id'])
        except DmpVideoFans.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        if checkFieldExist(request, 'name'):
            fans.name = request.data['name']
        if checkFieldExist(request, 'freq'):
            fans.freq = request.data['freq']
        if checkFieldExist(request, 'end_date'):
            fans.end_date = request.data['end_date']
        if checkFieldExist(request, 'couchbase_flag'):
            fans.couchbase_flag = request.data['couchbase_flag']
        if checkFieldExist(request, 'status'):
            fans.status = request.data['status']
        fans.save()
        serializer_context = {
            'request': Request(request),
        }
        res = DmpVideoFansSerializer(instance=fans, context=serializer_context)
        api_log('PUT DmpVideoFansView', request, fans, 'DEBUG')
        return Response(res.data)
