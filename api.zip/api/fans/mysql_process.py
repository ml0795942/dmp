# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang <zhangzhenghao@qiyi.com>

import os
import sys
import time
import logging

from pylib import pyinit, pymysql, pyudf

import config

LOG = logging.getLogger()


class DBAlgoBusiness(pymysql.PyMysql):

    def __init__(self):
        ip = config.DB_ALGO_TEST['ip']
        user = config.DB_ALGO_TEST['user']
        pwd = config.DB_ALGO_TEST['pwd']
        dbname = config.DB_ALGO_TEST['dbname']
        port = config.DB_ALGO_TEST['port']
        super(DBAlgoBusiness, self).__init__(ip, user, pwd, dbname, port=port)

    def star_episodes(self, star_name, results):
        sql_1 = "select id from qipu_person where name = '%s'" % (star_name) 
        id_result = self.sql(sql_1)
        if (len(id_result) == 0):
            return results
        id = id_result[0]['id']
        results[0] += str(id) + ';'
        sql_2 = "select id from qipu_episode where creators like '%%%s%%' or contributors like '%%%s%%'" % (id, id)
        id_tuples = self.sql(sql_2)
        for id_tuple in id_tuples:
            results[1] += str(id_tuple['id']) + ';'
        results[2] += len(id_tuples) 
        return results

    def album_episodes(self, album_name, results):
        sql = "select id from qipu_episode where name like '%%%s%%'" % (album_name)
        id_tuples = self.sql(sql)
        for id_tuple in id_tuples:
            results[0] += str(id_tuple['id']) + ';'
        results[1] += len(id_tuples)
        return results

    def list_name(self, names, type):
        names = names.strip()
        name_list = names.split(';') 
        if (type == 0):
            results = ['',0]
            for name in name_list:
                res = self.album_episodes(name, results)
            return res
        else:
            results = ['','',0]
            for name in name_list:
                res = self.star_episodes(name, results)
            return res 
                

if __name__ == '__main__':
    test = DBAlgoBusiness()
    print test.list_name('胡歌;宋慧乔',1)
