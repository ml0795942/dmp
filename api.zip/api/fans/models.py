# -*- coding: utf-8 -*-
# Author: Guanxiong Liu<liuguanxiong@qiyi.com>
#         Zhenghao Zhang<zhangzhenghao@qiyi.com>

from __future__ import unicode_literals

import datetime

from django.db import models


class DmpVideoFans(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    audience_target_id = models.BigIntegerField()
    freq = models.IntegerField()
    history_days = models.IntegerField(default='30')
    episodes = models.TextField()
    end_date = models.DateField(default=datetime.date.today()+datetime.timedelta(days=30))
    couchbase_flag = models.SmallIntegerField()
    cid_or_uid = models.SmallIntegerField()
    update_time = models.DateTimeField(auto_now=True)
    type = models.SmallIntegerField(default='0')
    ext_info = models.TextField()

    class Meta:
        db_table = 'dmp_video_fans'


class DmpVideoFansConvert(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    audience_target_id = models.CharField(max_length=255)
    freq = models.IntegerField()
    history_days = models.IntegerField(default='30')
    episodes = models.TextField()
    end_date = models.DateField(default=datetime.date.today()+datetime.timedelta(days=30))
    couchbase_flag = models.SmallIntegerField()
    cid_or_uid = models.SmallIntegerField()
    update_time = models.DateTimeField(auto_now=True)
    type = models.SmallIntegerField(default='0')
    ext_info = models.TextField()
