# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang <zhangzhenghao@qiyi.com>

#---------------------------
# ALGO_BUSINESS
#---------------------------
DB_ALGO_TEST = {
    'ip': 'bj.cupid2.r.qiyi.db',
    'user': 'cupid2',
    'pwd': 'kIhCZ]9s',
    'dbname': 'cupid2',
    'port': 6232
}
