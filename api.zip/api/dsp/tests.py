# -*- coding:utf-8 -*-
# Author: Zhenghao Zhang <zhangzhenghao@qiyi.com>

from django.test import TestCase
from rest_framework.test import APITestCase
from rest_framework.test import APIRequestFactory

from common import exception_info
from models import DmpDspInfo, DmpDspSchedule
from audience import tests 

INFO_URL = '/dsp/'
SCHEUDLE_URL = '/dsp/schedule/'

INFO_DATA = {'name': 'aaa', 'qps': 123, 'dsp_id': 200}
SCHEDULE_DATA = {'name': 'aaa', 'dsp_id': 200, 'start_date': '2016-03-28', 'end_date':'2016-03-28', 'audiences': '20000001'}


class DspInfoTest(APITestCase):

    def test_create_dsp(self):
        data = {'name': 'aaa', 'qps': 'asdf'}
        response = self.client.post(INFO_URL, data, format='json')
        self.assertContains(response, '"qps":["请填写合法的整数值。"],"dsp_id":["该字段是必填项。"]', status_code=400)
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        self.assertEquals(DmpDspInfo.objects.count(), 1)
        self.assertEquals(DmpDspInfo.objects.get(name='aaa').qps, 123)
        response = self.client.get(INFO_URL)
        self.assertContains(response, '"count":1', status_code=200)

    def test_put_dsp(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        data = {'id': 2, 'name': 'bbb'}
        response = self.client.put(INFO_URL, data, format='json')
        self.assertContains(response, exception_info.ID_NOT_EXIST, status_code=500)
        data = {'name': 'bbb'}
        response = self.client.put(INFO_URL, data, format='json')
        self.assertContains(response, exception_info.ID_REQUIRED, status_code=500)
        data = {'id': 1, 'name': 'bbb'}
        response = self.client.put(INFO_URL, data, format='json')
        self.assertEquals(DmpDspInfo.objects.get(id=1).name, 'bbb')
        data = {'id': 1, 'status': 2}
        response = self.client.put(INFO_URL, data, format='json')
        self.assertContains(response, exception_info.STATUS_OUT_OF_RANGE_2, status_code=500)


class DspScheduleTest(APITestCase):

    def test_create_schedule(self):
        data = {'name': 'aaa', 'dsp_id': 123, 'start_date': '2016-03-28', 'end_date':'2016-03-28', 'audiences': 'asd'}
        response = self.client.post(SCHEUDLE_URL, data, format='json')
        self.assertContains(response, exception_info.DSP_ID_NOT_EXIST, status_code=500)
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(tests.INFO_URL, tests.INFO_DATA, format='json')
        response = self.client.post(SCHEUDLE_URL, SCHEDULE_DATA, format='json')
        self.assertEquals(DmpDspSchedule.objects.count(), 1)
        response = self.client.get(SCHEUDLE_URL, data, format='json')
        self.assertContains(response, '"count":1', status_code=200)

    def test_audience_id_exist_test(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(tests.INFO_URL, tests.INFO_DATA, format='json')
        data = {'name': 'aaa', 'dsp_id': 200, 'start_date': '2016-03-28', 'end_date':'2016-03-28', 'audiences': '12341;20000001;123124'} 
        response = self.client.post(SCHEUDLE_URL, data, format='json')
        self.assertContains(response, exception_info.AUDIENCE_ID_NOT_EXIST, status_code=500)

    def test_put_schedule(self):
        response = self.client.post(INFO_URL, INFO_DATA, format='json')
        response = self.client.post(tests.INFO_URL, tests.INFO_DATA, format='json')
        response = self.client.post(SCHEUDLE_URL, SCHEDULE_DATA, format='json')
        data = {'id': 2, 'name': 'bbb'}
        response = self.client.put(SCHEUDLE_URL, data, format='json')
        self.assertContains(response, exception_info.ID_NOT_EXIST, status_code=500)
        data = {'id': 1, 'name': 'bbb', 'status': 5}
        response = self.client.put(SCHEUDLE_URL, data, format='json')
        self.assertContains(response, exception_info.STATUS_OUT_OF_RANGE_4, status_code=500)
        data = {'id': 1, 'name': 'bbb', 'status': 2, 'audiences': '20000001'}
        response = self.client.put(SCHEUDLE_URL, data, format='json')
        self.assertEquals(DmpDspSchedule.objects.get(id=1).status, 2)
        self.assertEquals(DmpDspSchedule.objects.get(id=1).name, 'bbb')
