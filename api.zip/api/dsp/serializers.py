# -*- coding: utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

from rest_framework import serializers

from models import DmpDspInfo 
from models import DmpDspSchedule


class DmpDspInfoSerializer(serializers.ModelSerializer):
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)

    class Meta:
        model = DmpDspInfo


class DmpDspInfoListResponseSerializer(serializers.Serializer):
    results = DmpDspInfoSerializer(many=True)
    page_size = serializers.IntegerField()
    count = serializers.IntegerField()


class DmpDspScheduleSerializer(serializers.ModelSerializer):
    start_date = serializers.DateField(format=None, input_formats=None)
    end_date = serializers.DateField(format=None, input_formats=None)

    class Meta:
        model = DmpDspSchedule

class DmpDspScheduleConvertSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()
    update_time = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', input_formats=None, required=False)
    status = serializers.IntegerField()
    delete_flag = serializers.IntegerField()
    dsp_id = serializers.IntegerField()
    start_date = serializers.DateField(format=None, input_formats=None)
    end_date = serializers.DateField(format=None, input_formats=None)
    audiences = serializers.CharField()
    audiences_id = serializers.CharField()


class DmpDspScheduleListResponseSerializer(serializers.Serializer):
    results = DmpDspScheduleConvertSerializer(many=True)
    page_size = serializers.IntegerField()
    count = serializers.IntegerField()


class DmpDspInfoResponseSerializer(serializers.Serializer):
    dsp_id = serializers.IntegerField()
    token = serializers.CharField()


class DmpDspScheduleIdResponseSerializer(serializers.Serializer):
    id = serializers.IntegerField()
