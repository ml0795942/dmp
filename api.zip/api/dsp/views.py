# -*- coding:utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

import time
import hashlib

from django.shortcuts import render
from django.core.exceptions import ObjectDoesNotExist
from django.core import serializers
from rest_framework import viewsets
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import exceptions

from common import exception_info
from common.json_response import ListResponse, IdToken, ReturnId
from common.utils import api_log, calPageStartEnd, checkFieldExist, checkStatusField, column_order, search_result, res_handler, check_auth, audience_id_convert_name,object_value_migrate, add_user, check_perm
from models import DmpDspInfo, DmpDspSchedule, DmpDspScheduleConvert
from audience import models
from serializers import DmpDspInfoListResponseSerializer
from serializers import DmpDspScheduleListResponseSerializer
from serializers import DmpDspInfoResponseSerializer
from serializers import DmpDspScheduleIdResponseSerializer
from serializers import DmpDspScheduleSerializer
from serializers import DmpDspInfoSerializer


class DmpDspInfoView(viewsets.ViewSet):

    def create(self, request, format=None):
        check_auth(request)
        check_perm(request, 'dsp.add_dmpdspinfo')
        serializer = DmpDspInfoSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        # build model
        dsp = DmpDspInfo()
        dsp.name = request.data['name']
        dsp.qps = request.data['qps']
        dsp.dsp_id = request.data['dsp_id']
        dsp.token = generate_token(dsp.dsp_id)
        dsp.save()
        serializer_context = {
            'request': Request(request),
        }
        id_token = IdToken(dsp_id=dsp.dsp_id, token=dsp.token)
        res = DmpDspInfoResponseSerializer(instance=id_token, context=serializer_context)
        api_log('POST DmpDspInfoView', request, dsp, 'DEBUG')
        return Response(res.data)

    def list(self, request, foramt=None):
        add_user(request)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        results = DmpDspInfo.objects.all()
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            value_convert_json = {'status' : {0 : '无效',1 : '有效',}}
            keys = ['status']
            temp_results = results
            res_handler(temp_results, keys, value_convert_json)
            list = search_result(results,temp_results, search)
            results = DmpDspInfo.objects.filter(id__in=list)
        results = column_order(results, sort, order)
        count = len(results)
	(start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        list_response = ListResponse(count, page_size, page_results)
        serializer_context = {'request': Request(request)}
        res = DmpDspInfoListResponseSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)

    def put(self, request, pk=None, format=None):
        check_auth(request)
        check_perm(request, 'dsp.add_dmpdspinfo')
        if not checkFieldExist(request, 'id'):
            raise exceptions.APIException(exception_info.ID_REQUIRED)
        try:
            dsp = DmpDspInfo.objects.get(id=request.data['id'])
        except DmpDspInfo.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        # fill model
        if checkFieldExist(request, 'name'):
            dsp.name = request.data['name']
        if checkFieldExist(request, 'status'):
            if not checkStatusField(request, 2):
                raise exceptions.APIException(exception_info.STATUS_OUT_OF_RANGE_2)
            dsp.status = request.data['status']
        if checkFieldExist(request, 'qps'):
            dsp.qps = request.data['qps']
        dsp.save()
        serializer_context = {
            'request': Request(request),
        }
        res = DmpDspInfoSerializer(instance=dsp, context=serializer_context)
        api_log('PUT DmpDspInfoView', request, dsp, 'DEBUG')
        return Response(res.data)


class DmpDspScheduleView(viewsets.ViewSet):

    def create(self, request, format=None):
        check_auth(request)
        check_perm(request, 'dsp.add_dmpdspschedule')
        serializer = DmpDspScheduleSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        # build model
        schedule = DmpDspSchedule()
        schedule.name = request.data['name']
        schedule.dsp_id = request.data['dsp_id']
        try:
            DmpDspInfo.objects.get(dsp_id=request.data['dsp_id'])
        except:
            raise exceptions.APIException(exception_info.DSP_ID_NOT_EXIST)
        schedule.start_date = request.data['start_date']
        schedule.end_date = request.data['end_date']
        schedule.audiences = request.data['audiences']
        schedule.save()
        dsp = DmpDspSchedule.objects.get(dsp_id=schedule.dsp_id,update_time=schedule.update_time)
        response_id = ReturnId(dsp.id)
        serializer_context = {
            'request': Request(request),
        }
        res = DmpDspScheduleIdResponseSerializer(instance=response_id, context=serializer_context)
        api_log('POST DmpDspScheduleView', request, schedule, 'DEBUG')
        return Response(res.data)

    def list(self, request, foramt=None):
        add_user(request)
        page_size = int(request.query_params.get('page_size', '-1'))
        page = int(request.query_params.get('page', '1'))
        results = DmpDspSchedule.objects.all()
        order = request.query_params.get('order', 'asc')
        sort = request.query_params.get('sort', 'id')
        search = request.query_params.get('search')
        if (search):
            value_convert_json = {'status' : {0 : '创建待确认',1 : '投放中',2 : '暂停',3 : '终止',}}
            keys = ['status']
            temp_results = results
            res_handler(temp_results, keys, value_convert_json)
            list = search_result(results,temp_results, search)
            results = DmpDspSchedule.objects.filter(id__in=list)
        results = column_order(results, sort, order)
        count = len(results)
        (start, end) = calPageStartEnd(page, page_size, count)
        page_results = results[start:end]
        convert_results = []
        results = page_results
        for result in results:
            task = DmpDspScheduleConvert()
            object_value_migrate(task, result)
            task.audiences_id = result.audiences
            convert_results.append(task)
        for result in convert_results:
            result.audiences = audience_id_convert_name(result.audiences)
        list_response = ListResponse(count, page_size, convert_results)
        serializer_context = {'request': Request(request)}
        res = DmpDspScheduleListResponseSerializer(instance=list_response, context=serializer_context)
        return Response(res.data)

    def put(self, request, pk=None, format=None):
        check_auth(request)
        check_perm(request, 'dsp.change_dmpdspschedule')
        if not checkFieldExist(request, 'id'): raise exceptions.APIException(exception_info.ID_REQUIRED)
        try:
            dsp = DmpDspSchedule.objects.get(id=request.data['id'])
        except DmpDspSchedule.DoesNotExist:
            raise exceptions.APIException(exception_info.ID_NOT_EXIST)
        # fill model
        if checkFieldExist(request, 'name'):
            dsp.name = request.data['name']
        if checkFieldExist(request, 'status'):
            if not checkStatusField(request, 4):
                raise exceptions.APIException(exception_info.STATUS_OUT_OF_RANGE_4)
            dsp.status = request.data['status']
        if checkFieldExist(request, 'delete_flag'):
            dsp.delete_flag = request.data['delete_flag']
        if checkFieldExist(request, 'start_date'):
            dsp.start_date = request.data['start_date']
        if checkFieldExist(request, 'end_date'):
            dsp.end_date = request.data['end_date']
        if checkFieldExist(request, 'audiences'):
            print request.data['audiences']
            dsp.audiences = request.data['audiences']
            #not_audience = checkAudienceIdExist(request)
            #if not_audience == []:
            #    dsp.audiences = request.data['audiences']
            #else:
            #    raise exceptions.APIException(exception_info.AUDIENCE_ID_NOT_EXIST + ": %s" % not_audience)
        dsp.save()
        serializer_context = {
            'request': Request(request),
        }
        res = DmpDspScheduleSerializer(instance=dsp, context=serializer_context)
        print res
        api_log('PUT DmpDspScheduleView', request, dsp, 'DEBUG')
        return Response(res.data)


def generate_token(dsp_id):
    """This function is used for generating token with dsp_id and timestamp"""
    concrete = str(dsp_id) + str(time.time())
    m = hashlib.md5()
    m.update(concrete)
    token = m.hexdigest()
    return token

def checkAudienceIdExist(request):
    """Check input audiences exist or not"""
    audience_id = request.data['audiences']
    audience_id = audience_id.split(';')
    not_exist_audience = []
    for id in audience_id:
        id = int(id.strip())
        if models.DmpAudienceInfo.objects.filter(id=id).count() == 0:
            not_exist_audience.append(id)
    return not_exist_audience

