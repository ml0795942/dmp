# -*- coding: utf-8 -*-
# Authors: Guanxiong Liu<liuguanxiong@qiyi.com>
#          Zhenghao Zhang<zhangzhenghao@qiyi.com>

from __future__ import unicode_literals

from django.db import models


class DmpDspInfo(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    update_time = models.DateTimeField(auto_now=True)
    # default for ignore validation error
    token = models.CharField(max_length=255, default='')
    status = models.SmallIntegerField(default='1')
    qps = models.IntegerField()
    dsp_id = models.BigIntegerField()

    class Meta:
        db_table = 'dmp_dsp_info'


class DmpDspSchedule(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    update_time = models.DateTimeField(auto_now=True)
    status = models.SmallIntegerField(default='0')
    delete_flag = models.SmallIntegerField(default='0')
    dsp_id = models.BigIntegerField()
    start_date = models.DateField()
    end_date = models.DateField()
    audiences = models.TextField()
   
    class Meta:
        db_table = 'dmp_dsp_schedule'
 

class DmpDspScheduleConvert(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    update_time = models.DateTimeField(auto_now=True)
    status = models.SmallIntegerField(default='0')
    delete_flag = models.SmallIntegerField(default='0')
    dsp_id = models.BigIntegerField()
    start_date = models.DateField()
    end_date = models.DateField()
    audiences = models.TextField()
    audiences_id = models.TextField()
